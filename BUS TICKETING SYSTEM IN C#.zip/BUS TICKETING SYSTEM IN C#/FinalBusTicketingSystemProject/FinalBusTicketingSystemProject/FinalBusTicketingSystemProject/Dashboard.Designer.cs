﻿namespace FinalBusTicketingSystemProject
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            roundedPanel1 = new RoundedPanel();
            label3 = new Label();
            roundedPanel2 = new RoundedPanel();
            pictureBox2 = new PictureBox();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            roundedPanel3 = new RoundedPanel();
            label2 = new Label();
            roundedPanel1.SuspendLayout();
            roundedPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            roundedPanel3.SuspendLayout();
            SuspendLayout();
            // 
            // roundedPanel1
            // 
            roundedPanel1.BackColor = Color.FromArgb(192, 192, 255);
            roundedPanel1.Controls.Add(label3);
            roundedPanel1.Controls.Add(roundedPanel2);
            roundedPanel1.Controls.Add(label8);
            roundedPanel1.Controls.Add(label9);
            roundedPanel1.Controls.Add(label10);
            roundedPanel1.Controls.Add(label11);
            roundedPanel1.Controls.Add(label7);
            roundedPanel1.Controls.Add(label6);
            roundedPanel1.Controls.Add(label5);
            roundedPanel1.Controls.Add(label4);
            roundedPanel1.Controls.Add(roundedPanel3);
            roundedPanel1.Location = new Point(162, 69);
            roundedPanel1.Margin = new Padding(3, 4, 3, 4);
            roundedPanel1.Name = "roundedPanel1";
            roundedPanel1.Radius = 40;
            roundedPanel1.Size = new Size(1159, 757);
            roundedPanel1.TabIndex = 0;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe Script", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.MidnightBlue;
            label3.Location = new Point(101, 579);
            label3.Name = "label3";
            label3.Size = new Size(216, 44);
            label3.TabIndex = 13;
            label3.Text = "- Team Dasig";
            // 
            // roundedPanel2
            // 
            roundedPanel2.Controls.Add(pictureBox2);
            roundedPanel2.Location = new Point(466, 251);
            roundedPanel2.Margin = new Padding(3, 4, 3, 4);
            roundedPanel2.Name = "roundedPanel2";
            roundedPanel2.Radius = 20;
            roundedPanel2.Size = new Size(624, 439);
            roundedPanel2.TabIndex = 23;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Margin = new Padding(3, 4, 3, 4);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(635, 439);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 16;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.ForeColor = Color.MidnightBlue;
            label8.Location = new Point(101, 531);
            label8.Name = "label8";
            label8.Size = new Size(68, 20);
            label8.TabIndex = 22;
            label8.Text = "Frontend";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.ForeColor = Color.MidnightBlue;
            label9.Location = new Point(101, 457);
            label9.Name = "label9";
            label9.Size = new Size(68, 20);
            label9.TabIndex = 21;
            label9.Text = "Frontend";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.ForeColor = Color.MidnightBlue;
            label10.Location = new Point(101, 384);
            label10.Name = "label10";
            label10.Size = new Size(72, 20);
            label10.TabIndex = 20;
            label10.Text = "Database";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.ForeColor = Color.MidnightBlue;
            label11.Location = new Point(101, 304);
            label11.Name = "label11";
            label11.Size = new Size(65, 20);
            label11.TabIndex = 19;
            label11.Text = "Backend";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Historic", 12F, FontStyle.Bold);
            label7.ForeColor = Color.MidnightBlue;
            label7.Location = new Point(97, 503);
            label7.Name = "label7";
            label7.Size = new Size(147, 28);
            label7.TabIndex = 18;
            label7.Text = "Nerey Balabat";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Historic", 12F, FontStyle.Bold);
            label6.ForeColor = Color.MidnightBlue;
            label6.Location = new Point(97, 429);
            label6.Name = "label6";
            label6.Size = new Size(190, 28);
            label6.TabIndex = 17;
            label6.Text = "Juliannne P. Bullen";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Historic", 12F, FontStyle.Bold);
            label5.ForeColor = Color.MidnightBlue;
            label5.Location = new Point(97, 356);
            label5.Name = "label5";
            label5.Size = new Size(200, 28);
            label5.TabIndex = 15;
            label5.Text = "Rod Vincent Capele";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Historic", 12F, FontStyle.Bold);
            label4.ForeColor = Color.MidnightBlue;
            label4.Location = new Point(97, 276);
            label4.Name = "label4";
            label4.Size = new Size(195, 28);
            label4.TabIndex = 14;
            label4.Text = "Edrean R. Supremo";
            // 
            // roundedPanel3
            // 
            roundedPanel3.BackColor = Color.White;
            roundedPanel3.Controls.Add(label2);
            roundedPanel3.Location = new Point(-99, -112);
            roundedPanel3.Margin = new Padding(3, 4, 3, 4);
            roundedPanel3.Name = "roundedPanel3";
            roundedPanel3.Radius = 150;
            roundedPanel3.Size = new Size(647, 285);
            roundedPanel3.TabIndex = 24;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.White;
            label2.Font = new Font("Segoe UI Variable Display", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(141, 149);
            label2.Name = "label2";
            label2.Size = new Size(425, 53);
            label2.TabIndex = 12;
            label2.Text = "Bus Ticketing System";
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(29, 29, 43);
            ClientSize = new Size(1355, 876);
            Controls.Add(roundedPanel1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "Dashboard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Dashboard";
            roundedPanel1.ResumeLayout(false);
            roundedPanel1.PerformLayout();
            roundedPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            roundedPanel3.ResumeLayout(false);
            roundedPanel3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private RoundedPanel roundedPanel1;
        private PictureBox pictureBox2;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label3;
        private Label label4;
        private Label label2;
        private RoundedPanel roundedPanel2;
        private RoundedPanel roundedPanel3;
    }
}