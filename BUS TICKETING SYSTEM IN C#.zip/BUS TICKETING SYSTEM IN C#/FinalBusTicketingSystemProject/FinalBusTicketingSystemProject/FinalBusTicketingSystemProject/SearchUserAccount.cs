﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalBusTicketingSystemProject
{

    public partial class LookAtUserAccount : Form
    {
        private string RFID;
        private string connectionString = "Server=localhost;Port=3306;Database=database;Uid=root;Pwd=;";
        public LookAtUserAccount(string rFID)
        {
            InitializeComponent();
            RFID = rFID;
            ProcessRFID();
        }
        private class RFIDInfo
        {
            
            public string FullName { get; set; }
            public string Balance { get; set; }
            public string Phone { get; set; }
            public string Email { get; set; }
            public string Birthday { get; set; }
            public string CivilStatus { get; set; }
            public string RFID { get; set; }
            public string Destination { get; set; }
            public int Passengers { get; set; }
            public decimal CurrentBalance { get; set; }
            public decimal TotalAmount { get; set; }
        }
        private void UpdateCurrencyLabel(Label label, string amount)
        {
            if (decimal.TryParse(amount, out decimal decimalAmount))
            {
                label.Text = decimalAmount.ToString("C2", System.Globalization.CultureInfo.CreateSpecificCulture("en-US"));
            }
            else
            {
                label.Text = "Invalid amount";
            }
        }
        private void ProcessRFID()
        {
            // Process the RFID
            string scannedRFID = RFID;
            RFIDInfo info = ReadRFID(scannedRFID);

            if (info != null)
            {
                label5.Text = info.FullName;
                label4.Text = info.RFID;
                label11.Text = info.Phone; //phone
                label12.Text = info.Email; //email
                label13.Text = info.Birthday; //birthday
                label14.Text = info.CivilStatus; //civil status
                UpdateCurrencyLabel(label2, info.Balance); // Update label8 with formatted balance
            }
            else
            {
                label2.Text = "";
                label5.Text = "";
                label8.Text = "";
            }
        }

        private RFIDInfo ReadRFID(string scannedRFID)
        {
            string connectionString = "Server=localhost;Port=3306;Database=database;Uid=root;Pwd=";
            string query = "SELECT FirstName, MiddleInitial, LastName, RFID_Number, Balance, CivilStatus, Birthday, PhoneNumber, EmailAddress FROM personal_information WHERE RFID_Number = @RFID";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@RFID", scannedRFID);

                    try
                    {
                        connection.Open();
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string firstName = reader["FirstName"].ToString();
                                string middleInitial = reader["MiddleInitial"].ToString();
                                string lastName = reader["LastName"].ToString();

                                // Concatenate and capitalize the full name
                                string fullName = $"{firstName.ToUpper()} {middleInitial.ToUpper()}. {lastName.ToUpper()}";

                                return new RFIDInfo
                                {

                                    FullName = fullName,
                                    RFID = reader["RFID_Number"].ToString(),
                                    Phone = reader["PhoneNumber"].ToString(),
                                    Email = reader["EmailAddress"].ToString(),
                                    Birthday = reader["Birthday"].ToString(),
                                    CivilStatus = reader["CivilStatus"].ToString(),
                                    Balance = reader["Balance"].ToString()
                                };
                            }
                            else
                            {
                                return null;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                        return null;
                    }
                }
            }
        }
        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void roundedPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            DataTable users = GetUsers();

            DataGridView dataGridView = new DataGridView
            {
                DataSource = users,
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };

            // Clear panel controls before adding the DataGridView
            //panel1.Controls.Clear();
            panel1.Controls.Add(dataGridView);
        }
        private DataTable GetUsers()
        {
            DataTable usersTable = new DataTable();

            string query = "SELECT BusName, Destination, Date FROM bus_ticketing WHERE RFID_Number = @RFID"; // Adjust this query to match your database schema

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@RFID", RFID); // Use the class-level RFID variable

                        MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                        adapter.Fill(usersTable);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }

            return usersTable;
        }

        private void gradientPanel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
