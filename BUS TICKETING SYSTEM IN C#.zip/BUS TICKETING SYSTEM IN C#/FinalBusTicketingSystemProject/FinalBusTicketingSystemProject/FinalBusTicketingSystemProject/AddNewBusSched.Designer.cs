﻿namespace FinalBusTicketingSystemProject
{
    partial class AddNewBusSched
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddNewBusSched));
            roundedPanel1 = new RoundedPanel();
            button12 = new Button();
            button7 = new Button();
            panel1 = new Panel();
            roundedPanel2 = new RoundedPanel();
            dateTimePicker2 = new DateTimePicker();
            label1 = new Label();
            dateTimePicker1 = new DateTimePicker();
            label13 = new Label();
            label4 = new Label();
            label17 = new Label();
            comboBox2 = new ComboBox();
            label10 = new Label();
            comboBox1 = new ComboBox();
            label15 = new Label();
            label16 = new Label();
            label9 = new Label();
            label18 = new Label();
            label19 = new Label();
            textBox4 = new TextBox();
            roundedPanel3 = new RoundedPanel();
            label3 = new Label();
            roundedPanel1.SuspendLayout();
            roundedPanel2.SuspendLayout();
            roundedPanel3.SuspendLayout();
            SuspendLayout();
            // 
            // roundedPanel1
            // 
            roundedPanel1.BackColor = Color.FromArgb(192, 192, 255);
            roundedPanel1.Controls.Add(button12);
            roundedPanel1.Controls.Add(button7);
            roundedPanel1.Controls.Add(panel1);
            roundedPanel1.Controls.Add(roundedPanel2);
            roundedPanel1.Controls.Add(roundedPanel3);
            roundedPanel1.Location = new Point(59, 60);
            roundedPanel1.Margin = new Padding(3, 4, 3, 4);
            roundedPanel1.Name = "roundedPanel1";
            roundedPanel1.Radius = 40;
            roundedPanel1.Size = new Size(1236, 757);
            roundedPanel1.TabIndex = 1;
            roundedPanel1.Paint += roundedPanel1_Paint;
            // 
            // button12
            // 
            button12.BackColor = Color.FromArgb(27, 26, 40);
            button12.FlatStyle = FlatStyle.Popup;
            button12.ForeColor = SystemColors.ButtonFace;
            button12.Location = new Point(914, 652);
            button12.Margin = new Padding(3, 4, 3, 4);
            button12.Name = "button12";
            button12.Size = new Size(255, 61);
            button12.TabIndex = 109;
            button12.Text = "Save";
            button12.UseVisualStyleBackColor = false;
            button12.Click += button12_Click;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(192, 192, 255);
            button7.FlatAppearance.BorderSize = 0;
            button7.FlatStyle = FlatStyle.Flat;
            button7.ForeColor = SystemColors.ButtonFace;
            button7.Image = (Image)resources.GetObject("button7.Image");
            button7.Location = new Point(0, 0);
            button7.Margin = new Padding(3, 4, 3, 4);
            button7.Name = "button7";
            button7.Size = new Size(77, 56);
            button7.TabIndex = 116;
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // panel1
            // 
            panel1.Location = new Point(99, 141);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1070, 24);
            panel1.TabIndex = 119;
            // 
            // roundedPanel2
            // 
            roundedPanel2.BackColor = Color.White;
            roundedPanel2.Controls.Add(dateTimePicker2);
            roundedPanel2.Controls.Add(label1);
            roundedPanel2.Controls.Add(dateTimePicker1);
            roundedPanel2.Controls.Add(label13);
            roundedPanel2.Controls.Add(label4);
            roundedPanel2.Controls.Add(label17);
            roundedPanel2.Controls.Add(comboBox2);
            roundedPanel2.Controls.Add(label10);
            roundedPanel2.Controls.Add(comboBox1);
            roundedPanel2.Controls.Add(label15);
            roundedPanel2.Controls.Add(label16);
            roundedPanel2.Controls.Add(label9);
            roundedPanel2.Controls.Add(label18);
            roundedPanel2.Controls.Add(label19);
            roundedPanel2.Controls.Add(textBox4);
            roundedPanel2.Location = new Point(99, 152);
            roundedPanel2.Margin = new Padding(3, 4, 3, 4);
            roundedPanel2.Name = "roundedPanel2";
            roundedPanel2.Radius = 20;
            roundedPanel2.Size = new Size(1070, 463);
            roundedPanel2.TabIndex = 0;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.CalendarMonthBackground = Color.LightGray;
            dateTimePicker2.Checked = false;
            dateTimePicker2.Location = new Point(575, 375);
            dateTimePicker2.Margin = new Padding(3, 4, 3, 4);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(233, 27);
            dateTimePicker2.TabIndex = 146;
            dateTimePicker2.Value = new DateTime(2024, 4, 14, 20, 48, 0, 0);
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Calibri", 9F);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(530, 384);
            label1.Name = "label1";
            label1.Size = new Size(37, 18);
            label1.TabIndex = 149;
            label1.Text = "Date";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.CalendarMonthBackground = Color.LightGray;
            dateTimePicker1.Checked = false;
            dateTimePicker1.Location = new Point(575, 263);
            dateTimePicker1.Margin = new Padding(3, 4, 3, 4);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(233, 27);
            dateTimePicker1.TabIndex = 144;
            dateTimePicker1.Value = new DateTime(2024, 4, 14, 20, 48, 0, 0);
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Calibri", 12F, FontStyle.Bold);
            label13.ForeColor = Color.Black;
            label13.Location = new Point(530, 322);
            label13.Name = "label13";
            label13.Size = new Size(80, 24);
            label13.TabIndex = 147;
            label13.Text = "ARRIVAL";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Calibri", 9F);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(530, 263);
            label4.Name = "label4";
            label4.Size = new Size(37, 18);
            label4.TabIndex = 148;
            label4.Text = "Date";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Calibri", 12F, FontStyle.Bold);
            label17.ForeColor = Color.Black;
            label17.Location = new Point(530, 216);
            label17.Name = "label17";
            label17.Size = new Size(110, 24);
            label17.TabIndex = 145;
            label17.Text = "DEPARTURE";
            // 
            // comboBox2
            // 
            comboBox2.BackColor = Color.LightGray;
            comboBox2.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox2.FormattingEnabled = true;
            comboBox2.ItemHeight = 21;
            comboBox2.Items.AddRange(new object[] { "Tagbilaran -  Dauis", "Tagbilaran - Loon", "Tagbilaran - Baclayon", "Tagbilaran - Biking ", "Tagbilaran  - Panglao" });
            comboBox2.Location = new Point(613, 88);
            comboBox2.Margin = new Padding(3, 4, 3, 4);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(370, 29);
            comboBox2.TabIndex = 142;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Calibri", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.Black;
            label10.Location = new Point(519, 96);
            label10.Name = "label10";
            label10.Size = new Size(78, 18);
            label10.TabIndex = 141;
            label10.Text = "Destination";
            // 
            // comboBox1
            // 
            comboBox1.BackColor = Color.LightGray;
            comboBox1.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox1.FormattingEnabled = true;
            comboBox1.ItemHeight = 21;
            comboBox1.Items.AddRange(new object[] { "Victory Liner -  TYR 123", "Genesis Transport - ABC 456", "Ceres Liner - XYZ 789", "Philtranco - LMN 321", "Dimple Star Transport - DEF 654" });
            comboBox1.Location = new Point(169, 96);
            comboBox1.Margin = new Padding(3, 4, 3, 4);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(308, 29);
            comboBox1.TabIndex = 137;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label15.ForeColor = Color.Black;
            label15.Location = new Point(507, 47);
            label15.Name = "label15";
            label15.Size = new Size(199, 24);
            label15.TabIndex = 101;
            label15.Text = "ROUTE INFORMATION ";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.ForeColor = Color.Black;
            label16.Location = new Point(73, 49);
            label16.Name = "label16";
            label16.Size = new Size(169, 24);
            label16.TabIndex = 100;
            label16.Text = "BUS INFORMATION";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.Black;
            label9.Location = new Point(89, 226);
            label9.Name = "label9";
            label9.Size = new Size(117, 24);
            label9.TabIndex = 108;
            label9.Text = "TRIP DETAILS";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Calibri", 9F);
            label18.ForeColor = Color.Black;
            label18.Location = new Point(89, 266);
            label18.Name = "label18";
            label18.Size = new Size(147, 18);
            label18.TabIndex = 99;
            label18.Text = "Number of Passengers";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Calibri", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label19.ForeColor = Color.Black;
            label19.Location = new Point(73, 104);
            label19.Name = "label19";
            label19.Size = new Size(70, 18);
            label19.TabIndex = 96;
            label19.Text = "Bus Name";
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.LightGray;
            textBox4.BorderStyle = BorderStyle.None;
            textBox4.Font = new Font("Segoe UI", 12F);
            textBox4.ForeColor = Color.Black;
            textBox4.Location = new Point(88, 289);
            textBox4.Margin = new Padding(3, 4, 3, 4);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(199, 27);
            textBox4.TabIndex = 98;
            // 
            // roundedPanel3
            // 
            roundedPanel3.BackColor = Color.FromArgb(255, 193, 58);
            roundedPanel3.Controls.Add(label3);
            roundedPanel3.Location = new Point(99, 89);
            roundedPanel3.Margin = new Padding(3, 4, 3, 4);
            roundedPanel3.Name = "roundedPanel3";
            roundedPanel3.Radius = 20;
            roundedPanel3.Size = new Size(1070, 71);
            roundedPanel3.TabIndex = 120;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.FromArgb(255, 193, 58);
            label3.Font = new Font("Segoe UI Variable Display", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(31, 11);
            label3.Name = "label3";
            label3.Size = new Size(175, 36);
            label3.TabIndex = 95;
            label3.Text = "BOOK A BUS";
            // 
            // AddNewBusSched
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(29, 29, 43);
            ClientSize = new Size(1355, 876);
            Controls.Add(roundedPanel1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "AddNewBusSched";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "AddNewBusSched";
            roundedPanel1.ResumeLayout(false);
            roundedPanel2.ResumeLayout(false);
            roundedPanel2.PerformLayout();
            roundedPanel3.ResumeLayout(false);
            roundedPanel3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private RoundedPanel roundedPanel1;
        private RoundedPanel roundedPanel2;
        private Panel panel1;
        private Label label3;
        private Label label16;
        private Label label9;
        private TextBox textBox4;
        private Label label19;
        private Label label18;
        private Label label15;
        private Button button12;
        private Button button7;
        private RoundedPanel roundedPanel3;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private Label label10;
        private DateTimePicker dateTimePicker2;
        private Label label1;
        private DateTimePicker dateTimePicker1;
        private Label label13;
        private Label label4;
        private Label label17;
    }
}