﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FinalBusTicketingSystemProject
{
    public partial class BookTicket : Form
    {
        private string connectionString = "Server=localhost;Port=3306;Database=database;Uid=root;Pwd=;";
        public BookTicket()
        {
            InitializeComponent();
            PopulateBusComboBox();
            textBox5.KeyPress += TextBox1_KeyPress;
        }
        private void TextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow only numeric characters and control keys
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Prevent the character from being entered
            }
        }
        private void PopulateBusComboBox()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT DISTINCT Bus_name FROM bus_information";
                    MySqlCommand command = new MySqlCommand(query, connection);
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            comboBox1.Items.Add(reader["Bus_name"].ToString());
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
        private void roundedPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedBus = comboBox1.SelectedItem.ToString();
            string route = GetBusRoute(selectedBus);
            label4.Text = route;
        }
        private string GetBusRoute(string busName)
        {
            string route = "";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT Route FROM bus_information WHERE Bus_name = @BusName";
                    MySqlCommand command = new MySqlCommand(query, connection);
                    command.Parameters.AddWithValue("@BusName", busName);
                    object result = command.ExecuteScalar();
                    if (result != null)
                    {
                        route = result.ToString();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            return route;
        }
        private decimal GetBalanceForRFID(string rfid)
        {
            decimal balance = 0;

            try
            {
                string query = "SELECT Balance FROM personal_information WHERE RFID_Number = @RFID";

                using (MySqlConnection connection = new MySqlConnection(connectionString))
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@RFID", rfid);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        // Handle potential data type issues
                        if (decimal.TryParse(result.ToString(), out balance))
                        {
                            return balance;
                        }
                        else
                        {
                            MessageBox.Show("Error: Unable to convert balance to decimal.");
                            return 0;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while retrieving balance: " + ex.Message);
            }

            return balance;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            // Retrieve user inputs
            string bus = comboBox1.Text;
            string rfid = textBox5.Text;
            string destination = label4.Text;
            string passengersStr = textBox4.Text;
            string date = dateTimePicker1.Text;
            string fareStr = textBox8.Text;




            // Validate input
            if (string.IsNullOrEmpty(bus) || string.IsNullOrEmpty(rfid) || string.IsNullOrEmpty(destination) ||
                string.IsNullOrEmpty(passengersStr) || string.IsNullOrEmpty(date) || string.IsNullOrEmpty(fareStr))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }
            // Convert fare and passengers to numeric values
            if (!decimal.TryParse(fareStr, out decimal fareValue) || !int.TryParse(passengersStr, out int passengers))
            {
                MessageBox.Show("Fare and Passengers must be numeric values.");
                return;
            }
            // Calculate total amount
            decimal totalAmount = fareValue * passengers;

            // Retrieve the balance associated with the RFID
            decimal balance = GetBalanceForRFID(rfid);
            // Check if the balance is sufficient for booking
            if (balance < totalAmount)
            {
                MessageBox.Show("Insufficient balance to book the ticket.");
                return;
            }

            // Retrieve the selected date from dateTimePicker
            DateTime selectedDate = dateTimePicker1.Value.Date;
            string status = "active";

            // Connect to database and insert data
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "INSERT INTO bus_ticketing (`RFID_Number`, `BusName`, `Destination`, `Date`, `Passengers`, `Price`, `TotalAmount`, `TicketStatus`) " +
                                   "VALUES (@RFID, @BusName, @Destination, @Date, @Seats, @Price, @Total, @TicketStatus)";

                    MySqlCommand command = new MySqlCommand(query, connection);
                    command.Parameters.AddWithValue("@RFID", rfid);
                    command.Parameters.AddWithValue("@BusName", bus);
                    command.Parameters.AddWithValue("@Destination", destination);
                    command.Parameters.AddWithValue("@Date", selectedDate.ToString("yyyy-MM-dd HH:mm:ss"));
                    command.Parameters.AddWithValue("@Seats", passengers);
                    command.Parameters.AddWithValue("@Price", fareStr);
                    command.Parameters.AddWithValue("@Total", totalAmount);
                    command.Parameters.AddWithValue("@TicketStatus", status);

                    int rowsAffected = command.ExecuteNonQuery(); //Error: Column count doesnt match value count at row 1

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Booking successful.");

                        //after booking, this form will be dispose/close
                        this.Dispose();
                    }
                    else
                    {
                        MessageBox.Show("Booking failed.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

