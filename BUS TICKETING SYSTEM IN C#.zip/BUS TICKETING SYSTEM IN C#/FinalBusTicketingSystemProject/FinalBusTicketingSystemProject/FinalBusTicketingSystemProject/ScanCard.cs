﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FinalBusTicketingSystemProject
{
    public partial class ScanCard : Form
    {
        public ScanCard()
        {
            InitializeComponent();
             panel3.Hide();
            textBox2.KeyPress += TextBox1_KeyPress;
        }
        private void TextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow only numeric characters and control keys
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Prevent the character from being entered
            }
        }


        private class BookingInfo
        {
            public string FullName { get; set; }
            public string RFID { get; set; }
            public string Destination { get; set; }
            public int Passengers { get; set; }
            public decimal CurrentBalance { get; set; }
            public decimal TotalAmount { get; set; }
        }

        private BookingInfo GetBookingInfo(string rfid, string selectedBus)
        {
            string connectionString = "Server=localhost;Port=3306;Database=database;Uid=root;Pwd=";
            string query = "SELECT CONCAT(p.FirstName, ' ', p.MiddleInitial, '. ', p.LastName) AS FullName, " +
                           "p.RFID_Number, b.Destination, b.Passengers, p.Balance, b.TotalAmount " +
                           "FROM bus_ticketing b " +
                           "JOIN personal_information p ON b.RFID_Number = p.RFID_Number " +
                           "WHERE p.RFID_Number = @RFID AND b.TicketStatus = 'active' AND b.BusName = @SelectedBus";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@RFID", rfid);
                    command.Parameters.AddWithValue("@SelectedBus", selectedBus);

                    try
                    {
                        connection.Open();
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new BookingInfo
                                {
                                    FullName = reader["FullName"].ToString(),
                                    RFID = reader["RFID_Number"].ToString(),
                                    Destination = reader["Destination"].ToString(),
                                    Passengers = Convert.ToInt32(reader["Passengers"]),
                                    CurrentBalance = Convert.ToDecimal(reader["Balance"]),
                                    TotalAmount = Convert.ToDecimal(reader["TotalAmount"])
                                };
                            }
                            else
                            {
                                return null; // No active booking found for the scanned RFID on the selected bus
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                        return null;
                    }
                }
            }
        }


        private bool UpdateBalanceAndTicketStatus(string rfid, decimal newBalance)
        {
            string connectionString = "Server=localhost;Port=3306;Database=database;Uid=root;Pwd=";
            string updateBalanceQuery = "UPDATE personal_information SET Balance = @NewBalance WHERE RFID_Number = @RFID";
            string updateTicketStatusQuery = "UPDATE bus_ticketing SET TicketStatus = 'inactive' WHERE RFID_Number = @RFID AND TicketStatus = 'active'";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand updateBalanceCommand = new MySqlCommand(updateBalanceQuery, connection))
                using (MySqlCommand updateTicketStatusCommand = new MySqlCommand(updateTicketStatusQuery, connection))
                {
                    updateBalanceCommand.Parameters.AddWithValue("@NewBalance", newBalance);
                    updateBalanceCommand.Parameters.AddWithValue("@RFID", rfid);
                    updateTicketStatusCommand.Parameters.AddWithValue("@RFID", rfid);

                    try
                    {
                        connection.Open();

                        // Start transaction
                        using (MySqlTransaction transaction = connection.BeginTransaction())
                        {
                            updateBalanceCommand.Transaction = transaction;
                            updateTicketStatusCommand.Transaction = transaction;

                            // Execute balance update
                            int balanceRows = updateBalanceCommand.ExecuteNonQuery();
                            if (balanceRows <= 0)
                            {
                                transaction.Rollback();
                                MessageBox.Show("Failed to update balance.");
                                return false;
                            }

                            // Execute ticket status update
                            int ticketRows = updateTicketStatusCommand.ExecuteNonQuery();
                            if (ticketRows <= 0)
                            {
                                transaction.Rollback();
                                MessageBox.Show("Failed to update ticket status.");
                                return false;
                            }

                            // Commit transaction if both updates were successful
                            transaction.Commit();
                            return true;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                        return false;
                    }
                }
            }
        }


        private void ProcessScannedRFID(string rfid)
        {
            // Check if an item is selected in the ComboBox
            if (comboBox1.SelectedItem != null)
            {
                string selectedBus = comboBox1.SelectedItem.ToString();
                BookingInfo bookingInfo = GetBookingInfo(rfid, selectedBus);

                if (bookingInfo != null)
                {
                    if (bookingInfo.CurrentBalance >= bookingInfo.TotalAmount)
                    {
                        decimal newBalance = bookingInfo.CurrentBalance - bookingInfo.TotalAmount;

                        if (UpdateBalanceAndTicketStatus(rfid, newBalance))
                        {
                            label2.Text = bookingInfo.FullName;
                            label5.Text = bookingInfo.RFID;
                            label17.Text = bookingInfo.Destination;
                            label10.Text = bookingInfo.Passengers.ToString();
                            label13.Text = newBalance.ToString("C");
                            label9.Text = bookingInfo.TotalAmount.ToString("C");
                        }
                        else
                        {
                            //panel3.Show();


                        }
                    }
                    else
                    {
                        panel3.Show();


                    }
                }
                else
                {
                    

                    panel3.Show();
                    //MessageBox.Show("No active booking found for the scanned RFID on the selected bus or bus name does not match.");

                }
            }
            else
            {
                panel3.Show();

                //MessageBox.Show("Please select a bus.");

            }
        }

        private void ClearLabels()
        {
            label2.Text = "";
            label5.Text = "";
            label17.Text = "";
            label10.Text = "";
            label13.Text = "";
            label9.Text = "";
        }



        private void button7_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text.Length == 10) // Assuming RFID is 10 characters long
            {
                string scannedRFID = textBox2.Text;
                ProcessScannedRFID(scannedRFID);
                textBox2.Clear(); // Clear the TextBox after processing
            }
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        /*private void ok_Click(object sender, EventArgs e)
        {
            ScanCard scan = new ScanCard();
            scan.Show();
            //this.Dispose();
        }*/

        private void gradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void roundedPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void roundedPanel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ScanCard scan = new ScanCard();
            scan.Show();
            this.Hide();
        }
    }
}
