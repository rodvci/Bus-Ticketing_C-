﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalBusTicketingSystemProject
{
    public partial class ManageBusSched : Form
    {
        private string connectionString = "Server=localhost;Port=3306;Database=database;Uid=root;Pwd=;";

        public ManageBusSched()
        {
            InitializeComponent();

        }




        private void button1_Click(object sender, EventArgs e)
        {

            AddNewBusSched addNewBusSched = new AddNewBusSched(this);

            addNewBusSched.Show();
            this.Dispose();
        }
        private DataTable GetUsers()
        {
            DataTable usersTable = new DataTable();

            string query = "SELECT BusID, Bus_name, Route, Passengers FROM bus_information"; // Adjust this query to match your database schema

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                        adapter.Fill(usersTable);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }

            return usersTable;
        }

        private void roundedPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            DataTable users = GetUsers();

            DataGridView dataGridView = new DataGridView
            {
                DataSource = users,
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };

            //panel1.Controls.Clear();
            panel1.Controls.Add(dataGridView);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
