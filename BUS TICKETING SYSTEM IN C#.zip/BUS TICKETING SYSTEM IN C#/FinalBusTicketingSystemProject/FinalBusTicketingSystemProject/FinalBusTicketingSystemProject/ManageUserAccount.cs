﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FinalBusTicketingSystemProject
{
    public partial class ManageUserAccount : Form
    {
        private string connectionString = "Server=localhost;Port=3306;Database=database;Uid=root;Pwd=;";
        
        public ManageUserAccount()
        {
            InitializeComponent();
           

        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            AddNewAccount addNewAccount = new AddNewAccount();

            addNewAccount.Show();
            this.Dispose();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string RFID = textBox1.Text;
            
      

                if (textBox1.Text != null)
                {
                    
                    LookAtUserAccount lookAtUserAccount = new LookAtUserAccount(RFID);

                    lookAtUserAccount.Show();
                }
                else {
                    MessageBox.Show("Searchbar Cannot be empty");
                }
            

            }
        private DataTable GetUsers()
        {
            DataTable usersTable = new DataTable();

            string query = "SELECT RFID_Number, FirstName, MiddleInitial, LastName, PhoneNumber, EmailAddress, CivilStatus, Balance FROM personal_information"; // Adjust this query to match your database schema

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                        adapter.Fill(usersTable);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }

            return usersTable;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            DataTable users = GetUsers();

            DataGridView dataGridView = new DataGridView
            {
                DataSource = users,
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };

            //panel1.Controls.Clear();
            panel1.Controls.Add(dataGridView);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            string rfid = textBox1.Text;

            if (string.IsNullOrEmpty(rfid))
            {
                MessageBox.Show("Please enter an RFID number.");
                return;
            }

            DataTable filteredUsers = FilterUsersByRFID(rfid);

            if (filteredUsers != null && filteredUsers.Rows.Count > 0)
            {
                // Display or use the filteredUsers DataTable as needed
                // For example, you can iterate through the rows and display them in a MessageBox
                string message = "User's Profile:\n";
                foreach (DataRow row in filteredUsers.Rows)
                {
                    message += $"RFID: {row["RFID_Number"]}\nName: {row["FirstName"]} {row["MiddleInitial"]} {row["LastName"]}\nBalance: ${row["Balance"]}";
                }
                MessageBox.Show(message);
            }
            else
            {
                MessageBox.Show("No user found with the provided RFID number.");
            }
        }
        private DataTable FilterUsersByRFID(string rfid)
        {
            DataTable usersTable = new DataTable();

            string query = "SELECT RFID_Number, FirstName, MiddleInitial, LastName, PhoneNumber, EmailAddress, CivilStatus, Balance " +
                           "FROM personal_information WHERE RFID_Number = @RFID";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@RFID", rfid);
                        MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                        adapter.Fill(usersTable);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }

            return usersTable;
        }
    }
}
