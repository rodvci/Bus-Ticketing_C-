﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FinalBusTicketingSystemProject
{
    public partial class AddNewAccount : Form
    {
        private string connectionString = "Server=localhost;Port=3306;Database=database;Uid=root;Pwd=;";
        public event EventHandler UserAdded;
        public AddNewAccount()
        {
            InitializeComponent();
            textBox1.KeyPress += textBox1_KeyPress;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ManageUserAccount m = new ManageUserAccount();
            m.Show();
            this.Dispose();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            // Retrieve user inputs
            string rfid = textBox1.Text;
            string firstname = textBox2.Text;
            string middleinitial = textBox3.Text;
            string lastname = textBox4.Text;
            string phonenumber = textBox5.Text;
            string email = textBox6.Text;
            string DateTimer = dateTimePicker1.Text;
            string civilstatus = comboBox7.Text;

            // Validate input
            if (string.IsNullOrEmpty(rfid) || string.IsNullOrEmpty(firstname) || string.IsNullOrEmpty(middleinitial) ||
                string.IsNullOrEmpty(lastname) || string.IsNullOrEmpty(phonenumber) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(DateTimer)
                || string.IsNullOrEmpty(civilstatus))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }
            // Retrieve the selected date from dateTimePicker
            DateTime selectedDate = dateTimePicker1.Value.Date;
            // Connect to database and insert data
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "INSERT INTO personal_information (`RFID_Number`, `FirstName`, `MiddleInitial`, `LastName`, `PhoneNumber`, `EmailAddress`, `Birthday`, `CivilStatus`, `Balance`) " +
                   "VALUES (@RFID, @FirstName, @MiddleInitial, @LastName, @PhoneNumber, @EmailAddress, @BoD, @CivilStatus, @Balance)";

                    MySqlCommand command = new MySqlCommand(query, connection);
                    command.Parameters.AddWithValue("@RFID", rfid);
                    command.Parameters.AddWithValue("@FirstName", firstname);
                    command.Parameters.AddWithValue("@MiddleInitial", middleinitial);
                    command.Parameters.AddWithValue("@LastName", lastname);
                    command.Parameters.AddWithValue("@PhoneNumber", phonenumber);
                    command.Parameters.AddWithValue("@EmailAddress", email);
                    command.Parameters.AddWithValue("@BoD", selectedDate);
                    command.Parameters.AddWithValue("@CivilStatus", civilstatus);
                    command.Parameters.AddWithValue("@Balance", 100);

                    int rowsAffected = command.ExecuteNonQuery(); //Error: Column count doesnt match value count at row 1

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Registration successful.");

                        // Raise the event
                        // UserAdded?.Invoke(this, EventArgs.Empty);
                        ManageUserAccount manage = new ManageUserAccount();

                        manage.Show();
                        //return to main frame after registration
                        this.Dispose();
                    }
                    else
                    {
                        MessageBox.Show("Registration failed.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void roundedPanel3_Paint(object sender, PaintEventArgs e)
        {

        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow only numeric characters and control keys
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Prevent the character from being entered
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
