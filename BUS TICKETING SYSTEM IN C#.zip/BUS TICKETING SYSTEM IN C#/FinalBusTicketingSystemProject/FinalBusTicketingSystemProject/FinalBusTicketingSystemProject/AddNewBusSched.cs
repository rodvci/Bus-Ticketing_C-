﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FinalBusTicketingSystemProject
{
    
    public partial class AddNewBusSched : Form
    {
        private string connectionString = "Server=localhost;Port=3306;Database=database;Uid=root;Pwd=;";
        private ManageBusSched manageBusSchedForm;
        public AddNewBusSched(ManageBusSched manageBusSchedForm)
        {
            InitializeComponent();
            this.manageBusSchedForm = manageBusSchedForm;
        }

        private void button7_Click(object sender, EventArgs e)
        {

            ManageBusSched m = new ManageBusSched();
            m.Show();
            this.Dispose();
        }

        private void roundedPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            // Retrieve user inputs
            string bus = comboBox1.Text;
            string destination = comboBox2.Text;
            int passengers;
            if (!int.TryParse(textBox4.Text, out passengers))
            {
                MessageBox.Show("Please enter a valid number for passengers.");
                return;
            }
            DateTime departure = dateTimePicker1.Value;
            DateTime arrival = dateTimePicker2.Value;

            // Validate input
            if (string.IsNullOrEmpty(bus) || string.IsNullOrEmpty(destination))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            // Check if the bus already exists
            if (BusExists(bus))
            {
                MessageBox.Show("Bus with the same name already exists.");
                return;
            }

            // Connect to database and insert data
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "INSERT INTO bus_information (Bus_name, Route, Passengers, Departure, Arrival) " +
                                   "VALUES (@Bus, @Route, @Passengers, @Departure, @Arrival)";

                    MySqlCommand command = new MySqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Bus", bus);
                    command.Parameters.AddWithValue("@Route", destination);
                    command.Parameters.AddWithValue("@Passengers", passengers);
                    command.Parameters.AddWithValue("@Departure", departure.ToString("yyyy-MM-dd HH:mm:ss")); // Format the date and time
                    command.Parameters.AddWithValue("@Arrival", arrival.ToString("yyyy-MM-dd HH:mm:ss")); // Format the date and time

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Bus schedule added successfully.");
                        ManageBusSched manage = new ManageBusSched();
                        
                        manage.Show();
                        this.Dispose();
                    }
                    else
                    {
                        MessageBox.Show("Adding bus schedule failed.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private bool BusExists(string busName)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "SELECT COUNT(*) FROM bus_information WHERE Bus_name = @Bus";
                    MySqlCommand command = new MySqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Bus", busName);

                    int count = Convert.ToInt32(command.ExecuteScalar());

                    return count > 0;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                    return true; // Return true to prevent insertion if an error occurs
                }
            }
        }
    }

}

