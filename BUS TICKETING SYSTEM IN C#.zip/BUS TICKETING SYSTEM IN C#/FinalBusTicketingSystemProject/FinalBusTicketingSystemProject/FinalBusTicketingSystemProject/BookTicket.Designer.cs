﻿namespace FinalBusTicketingSystemProject
{
    partial class BookTicket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BookTicket));
            roundedPanel1 = new RoundedPanel();
            button7 = new Button();
            button12 = new Button();
            panel1 = new Panel();
            roundedPanel2 = new RoundedPanel();
            textBox8 = new TextBox();
            label11 = new Label();
            label4 = new Label();
            label15 = new Label();
            label16 = new Label();
            textBox4 = new TextBox();
            label14 = new Label();
            dateTimePicker1 = new DateTimePicker();
            textBox5 = new TextBox();
            label9 = new Label();
            label19 = new Label();
            label10 = new Label();
            label3 = new Label();
            label17 = new Label();
            comboBox1 = new ComboBox();
            label18 = new Label();
            roundedPanel3 = new RoundedPanel();
            label2 = new Label();
            roundedPanel1.SuspendLayout();
            roundedPanel2.SuspendLayout();
            roundedPanel3.SuspendLayout();
            SuspendLayout();
            // 
            // roundedPanel1
            // 
            roundedPanel1.BackColor = Color.FromArgb(192, 192, 255);
            roundedPanel1.Controls.Add(button7);
            roundedPanel1.Controls.Add(button12);
            roundedPanel1.Controls.Add(panel1);
            roundedPanel1.Controls.Add(roundedPanel2);
            roundedPanel1.Controls.Add(roundedPanel3);
            roundedPanel1.Location = new Point(37, 69);
            roundedPanel1.Margin = new Padding(3, 4, 3, 4);
            roundedPanel1.Name = "roundedPanel1";
            roundedPanel1.Radius = 20;
            roundedPanel1.Size = new Size(1279, 757);
            roundedPanel1.TabIndex = 2;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(192, 192, 255);
            button7.FlatAppearance.BorderSize = 0;
            button7.FlatStyle = FlatStyle.Flat;
            button7.ForeColor = SystemColors.ButtonFace;
            button7.Image = (Image)resources.GetObject("button7.Image");
            button7.Location = new Point(0, 0);
            button7.Margin = new Padding(3, 4, 3, 4);
            button7.Name = "button7";
            button7.Size = new Size(77, 65);
            button7.TabIndex = 129;
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button12
            // 
            button12.BackColor = Color.FromArgb(27, 26, 40);
            button12.FlatStyle = FlatStyle.Popup;
            button12.ForeColor = SystemColors.ButtonFace;
            button12.Location = new Point(914, 652);
            button12.Margin = new Padding(3, 4, 3, 4);
            button12.Name = "button12";
            button12.Size = new Size(255, 61);
            button12.TabIndex = 126;
            button12.Text = "Save";
            button12.UseVisualStyleBackColor = false;
            button12.Click += button12_Click;
            // 
            // panel1
            // 
            panel1.Location = new Point(99, 141);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1070, 24);
            panel1.TabIndex = 127;
            // 
            // roundedPanel2
            // 
            roundedPanel2.BackColor = Color.White;
            roundedPanel2.Controls.Add(textBox8);
            roundedPanel2.Controls.Add(label11);
            roundedPanel2.Controls.Add(label4);
            roundedPanel2.Controls.Add(label15);
            roundedPanel2.Controls.Add(label16);
            roundedPanel2.Controls.Add(textBox4);
            roundedPanel2.Controls.Add(label14);
            roundedPanel2.Controls.Add(dateTimePicker1);
            roundedPanel2.Controls.Add(textBox5);
            roundedPanel2.Controls.Add(label9);
            roundedPanel2.Controls.Add(label19);
            roundedPanel2.Controls.Add(label10);
            roundedPanel2.Controls.Add(label3);
            roundedPanel2.Controls.Add(label17);
            roundedPanel2.Controls.Add(comboBox1);
            roundedPanel2.Controls.Add(label18);
            roundedPanel2.Location = new Point(99, 152);
            roundedPanel2.Margin = new Padding(3, 4, 3, 4);
            roundedPanel2.Name = "roundedPanel2";
            roundedPanel2.Radius = 20;
            roundedPanel2.Size = new Size(1070, 463);
            roundedPanel2.TabIndex = 125;
            // 
            // textBox8
            // 
            textBox8.BackColor = Color.LightGray;
            textBox8.BorderStyle = BorderStyle.None;
            textBox8.Font = new Font("Segoe UI", 12F);
            textBox8.ForeColor = Color.Black;
            textBox8.Location = new Point(660, 163);
            textBox8.Margin = new Padding(3, 4, 3, 4);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(234, 27);
            textBox8.TabIndex = 141;
            textBox8.TextChanged += textBox8_TextChanged;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Calibri", 9F);
            label11.ForeColor = Color.Black;
            label11.Location = new Point(578, 163);
            label11.Name = "label11";
            label11.Size = new Size(35, 18);
            label11.TabIndex = 142;
            label11.Text = "Fare";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Calibri", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(660, 98);
            label4.Name = "label4";
            label4.Size = new Size(163, 22);
            label4.TabIndex = 140;
            label4.Text = "*****************";
            label4.Click += label4_Click;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label15.ForeColor = Color.Black;
            label15.Location = new Point(539, 48);
            label15.Name = "label15";
            label15.Size = new Size(199, 24);
            label15.TabIndex = 124;
            label15.Text = "ROUTE INFORMATION ";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.ForeColor = Color.Black;
            label16.Location = new Point(105, 51);
            label16.Name = "label16";
            label16.Size = new Size(169, 24);
            label16.TabIndex = 123;
            label16.Text = "BUS INFORMATION";
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.LightGray;
            textBox4.BorderStyle = BorderStyle.None;
            textBox4.Font = new Font("Segoe UI", 12F);
            textBox4.ForeColor = Color.Black;
            textBox4.Location = new Point(104, 361);
            textBox4.Margin = new Padding(3, 4, 3, 4);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(199, 27);
            textBox4.TabIndex = 121;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Calibri", 9F);
            label14.ForeColor = Color.Black;
            label14.Location = new Point(105, 100);
            label14.Name = "label14";
            label14.Size = new Size(36, 18);
            label14.TabIndex = 126;
            label14.Text = "RFID";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.CalendarMonthBackground = Color.LightGray;
            dateTimePicker1.Checked = false;
            dateTimePicker1.Location = new Point(584, 346);
            dateTimePicker1.Margin = new Padding(3, 4, 3, 4);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(233, 27);
            dateTimePicker1.TabIndex = 132;
            dateTimePicker1.Value = new DateTime(2024, 4, 14, 20, 48, 0, 0);
            // 
            // textBox5
            // 
            textBox5.BackColor = Color.LightGray;
            textBox5.BorderStyle = BorderStyle.None;
            textBox5.Font = new Font("Segoe UI", 12F);
            textBox5.ForeColor = Color.Black;
            textBox5.Location = new Point(201, 92);
            textBox5.Margin = new Padding(3, 4, 3, 4);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(213, 27);
            textBox5.TabIndex = 125;
            textBox5.TextChanged += textBox5_TextChanged;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.Black;
            label9.Location = new Point(105, 299);
            label9.Name = "label9";
            label9.Size = new Size(117, 24);
            label9.TabIndex = 131;
            label9.Text = "TRIP DETAILS";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Calibri", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label19.ForeColor = Color.Black;
            label19.Location = new Point(105, 163);
            label19.Name = "label19";
            label19.Size = new Size(70, 18);
            label19.TabIndex = 119;
            label19.Text = "Bus Name";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Calibri", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.Black;
            label10.Location = new Point(539, 100);
            label10.Name = "label10";
            label10.Size = new Size(78, 18);
            label10.TabIndex = 128;
            label10.Text = "Destination";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Calibri", 9F);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(539, 346);
            label3.Name = "label3";
            label3.Size = new Size(37, 18);
            label3.TabIndex = 138;
            label3.Text = "Date";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Calibri", 12F, FontStyle.Bold);
            label17.ForeColor = Color.Black;
            label17.Location = new Point(539, 299);
            label17.Name = "label17";
            label17.Size = new Size(143, 24);
            label17.TabIndex = 133;
            label17.Text = "DATE AND TIME";
            // 
            // comboBox1
            // 
            comboBox1.BackColor = Color.LightGray;
            comboBox1.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox1.FormattingEnabled = true;
            comboBox1.ItemHeight = 21;
            comboBox1.Location = new Point(201, 155);
            comboBox1.Margin = new Padding(3, 4, 3, 4);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(212, 29);
            comboBox1.TabIndex = 136;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Calibri", 9F);
            label18.ForeColor = Color.Black;
            label18.Location = new Point(105, 339);
            label18.Name = "label18";
            label18.Size = new Size(147, 18);
            label18.TabIndex = 122;
            label18.Text = "Number of Passengers";
            // 
            // roundedPanel3
            // 
            roundedPanel3.BackColor = Color.FromArgb(255, 193, 58);
            roundedPanel3.Controls.Add(label2);
            roundedPanel3.Location = new Point(99, 89);
            roundedPanel3.Margin = new Padding(3, 4, 3, 4);
            roundedPanel3.Name = "roundedPanel3";
            roundedPanel3.Radius = 20;
            roundedPanel3.Size = new Size(1070, 71);
            roundedPanel3.TabIndex = 128;
            roundedPanel3.Paint += roundedPanel3_Paint;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(255, 193, 58);
            label2.Font = new Font("Segoe UI Variable Display", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(31, 11);
            label2.Name = "label2";
            label2.Size = new Size(237, 36);
            label2.TabIndex = 59;
            label2.Text = "BOOKING TICKET";
            // 
            // BookTicket
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoValidate = AutoValidate.EnablePreventFocusChange;
            BackColor = Color.FromArgb(29, 29, 43);
            ClientSize = new Size(1355, 876);
            Controls.Add(roundedPanel1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "BookTicket";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "BookTicket";
            roundedPanel1.ResumeLayout(false);
            roundedPanel2.ResumeLayout(false);
            roundedPanel2.PerformLayout();
            roundedPanel3.ResumeLayout(false);
            roundedPanel3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private RoundedPanel roundedPanel1;
        private Button button12;
        private RoundedPanel roundedPanel3;
        private Label label2;
        private Panel panel1;
        private RoundedPanel roundedPanel2;
        private Button button7;
        private Label label15;
        private Label label16;
        private TextBox textBox4;
        private Label label14;
        private TextBox textBox5;
        private Label label9;
        private Label label19;
        private Label label10;
        private ComboBox comboBox1;
        private Label label18;
        private Label label4;
        private DateTimePicker dateTimePicker1;
        private Label label3;
        private Label label17;
        private TextBox textBox8;
        private Label label11;
    }
}