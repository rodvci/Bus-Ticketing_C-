﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FinalBusTicketingSystemProject
{
    public partial class ManageHistory : Form
    {
        private string connectionString = "Server=localhost;Port=3306;Database=database;Uid=root;Pwd=;";
        public ManageHistory()
        {
            InitializeComponent();
        }

        private void ManageHistory_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            DataTable users = GetUsers();

            DataGridView dataGridView = new DataGridView
            {
                DataSource = users,
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };

            //panel1.Controls.Clear();
            panel1.Controls.Add(dataGridView);
        }
        private DataTable GetUsers()
        {
            DataTable usersTable = new DataTable();

            string query = "SELECT BookingNumber, RFID_Number, BusName, Destination, Date, Passengers, Price, TotalAmount, TicketStatus FROM bus_ticketing"; // Adjust this query to match your database schema

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                        adapter.Fill(usersTable);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }

            return usersTable;
        }
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string rfid = textBox1.Text;

            if (string.IsNullOrEmpty(rfid))
            {
                MessageBox.Show("Please enter an RFID number.");
                return;
            }

            DataTable filteredUsers = FilterUsersByRFID(rfid);

            if (filteredUsers != null && filteredUsers.Rows.Count > 0)
            {
                // Display or use the filteredUsers DataTable as needed
                // For example, you can iterate through the rows and display them in a MessageBox
                string message = "Booking informations:\n";
                foreach (DataRow row in filteredUsers.Rows)
                {
                    message += $"RFID: {row["RFID_Number"]}\nBus: {row["BusName"]}\nRoute: {row["Destination"]}\n";
                }
                MessageBox.Show(message);
            }
            else
            {
                MessageBox.Show("No user found with the provided RFID number.");
            }
        }
        private DataTable FilterUsersByRFID(string rfid)
        {
            DataTable usersTable = new DataTable();

            string query = "SELECT BookingNumber, RFID_Number, BusName, Destination, Date, Passengers, Price, TotalAmount, TicketStatus " +
                           "FROM bus_ticketing WHERE RFID_Number = @RFID";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@RFID", rfid);
                        MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                        adapter.Fill(usersTable);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }

            return usersTable;
        }
    }
}

