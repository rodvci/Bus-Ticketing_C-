
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalBusTicketingSystemProject
{
    public partial class MainContainer : Form
    {

        Dashboard dashboard;
        ManageBusSched manageBusSched;
        ManageUserAccount manageUserAccount;
        TopUpAmountBalance topUpAmountBalance;
        ScanCard scanCard;


        public MainContainer()
        {

            InitializeComponent();


            dashboard = new Dashboard();
            dashboard.FormClosed += Dashboard_FormClosed;
            dashboard.MdiParent = this;
            dashboard.Dock = DockStyle.Fill;
            dashboard.Show();

            /*
                        hardwareMonitor.HardwareStatusChanged += HardwareStatusChangedHandler;
                        hardwareMonitor.StartMonitoring();
                        panel4.Visible = false;*/

        }
        private void HomeButton_Click(object sender, EventArgs e)
        {
            if (dashboard == null)
            {
                dashboard = new Dashboard();
                dashboard.FormClosed += Dashboard_FormClosed;
                dashboard.MdiParent = this;
                dashboard.Dock = DockStyle.Fill;

                dashboard.Show();
            }
            else
            {
                dashboard.Activate();
            }
        }
        private void Dashboard_FormClosed(object sender, FormClosedEventArgs e)
        {
            dashboard = null;
        }
        private void ManageUserAccountButton_Click(object sender, EventArgs e)
        {

            ManageUserAccount manage = new ManageUserAccount();

            manage.Show();
        }
        private void ManageUserAccount_FormClosed(object sender, FormClosedEventArgs e)
        {
            manageUserAccount = null;
        }

        private void ManageBusesButton_Click(object sender, EventArgs e)
        {


            ManageBusSched manage = new ManageBusSched();

            manage.Show();
        }
        private void ManageBusSched_FormClosed(object sender, FormClosedEventArgs e)
        {
            manageBusSched = null;
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ScanCardButton_Click(object sender, EventArgs e)
        {
            ScanCard scanCard = new ScanCard();

            scanCard.Show();
        }

        private void TopUpAmountButton_Click(object sender, EventArgs e)
        {


            TopUpAmountBalance toop = new TopUpAmountBalance();

            toop.Show();
        }
        private void TopUpAmountBalance_FormClosed(object sender, FormClosedEventArgs e)
        {
            topUpAmountBalance = null;
        }

        private void ManageBookingButton_Click(object sender, EventArgs e)
        {
            BookTicket scanCard = new BookTicket();

            scanCard.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ManageHistory history = new ManageHistory();

            history.Show();
        }
    }

}
