﻿namespace FinalBusTicketingSystemProject
{
    partial class ManageUserAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ManageUserAccount));
            roundedPanel1 = new RoundedPanel();
            button7 = new Button();
            label3 = new Label();
            label4 = new Label();
            button4 = new Button();
            roundedPanel2 = new RoundedPanel();
            textBox1 = new TextBox();
            panel1 = new Panel();
            button1 = new Button();
            button3 = new Button();
            roundedPanel1.SuspendLayout();
            roundedPanel2.SuspendLayout();
            SuspendLayout();
            // 
            // roundedPanel1
            // 
            roundedPanel1.BackColor = Color.FromArgb(192, 192, 255);
            roundedPanel1.Controls.Add(button7);
            roundedPanel1.Controls.Add(label3);
            roundedPanel1.Controls.Add(label4);
            roundedPanel1.Controls.Add(button4);
            roundedPanel1.Controls.Add(roundedPanel2);
            roundedPanel1.Controls.Add(panel1);
            roundedPanel1.Controls.Add(button1);
            roundedPanel1.Controls.Add(button3);
            roundedPanel1.Location = new Point(59, 60);
            roundedPanel1.Margin = new Padding(3, 4, 3, 4);
            roundedPanel1.Name = "roundedPanel1";
            roundedPanel1.Radius = 40;
            roundedPanel1.Size = new Size(1236, 757);
            roundedPanel1.TabIndex = 1;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(192, 192, 255);
            button7.FlatAppearance.BorderSize = 0;
            button7.FlatStyle = FlatStyle.Flat;
            button7.ForeColor = SystemColors.ButtonFace;
            button7.Image = (Image)resources.GetObject("button7.Image");
            button7.Location = new Point(0, 0);
            button7.Margin = new Padding(3, 4, 3, 4);
            button7.Name = "button7";
            button7.Size = new Size(77, 57);
            button7.TabIndex = 129;
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Variable Display", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(35, 78);
            label3.Name = "label3";
            label3.Size = new Size(425, 53);
            label3.TabIndex = 18;
            label3.Text = "Bus Ticketing System";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Variable Display", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(39, 132);
            label4.Name = "label4";
            label4.Size = new Size(245, 27);
            label4.TabIndex = 17;
            label4.Text = "MANAGE USER ACCOUNT";
            // 
            // button4
            // 
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Image = (Image)resources.GetObject("button4.Image");
            button4.Location = new Point(712, 94);
            button4.Margin = new Padding(3, 4, 3, 4);
            button4.Name = "button4";
            button4.Size = new Size(50, 45);
            button4.TabIndex = 16;
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // roundedPanel2
            // 
            roundedPanel2.BackColor = Color.White;
            roundedPanel2.Controls.Add(textBox1);
            roundedPanel2.Location = new Point(769, 96);
            roundedPanel2.Margin = new Padding(3, 4, 3, 4);
            roundedPanel2.Name = "roundedPanel2";
            roundedPanel2.Radius = 20;
            roundedPanel2.Size = new Size(436, 43);
            roundedPanel2.TabIndex = 15;
            // 
            // textBox1
            // 
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(13, 10);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(420, 24);
            textBox1.TabIndex = 0;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(224, 224, 224);
            panel1.Location = new Point(35, 175);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1170, 438);
            panel1.TabIndex = 14;
            panel1.Paint += panel1_Paint;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(16, 87, 253);
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = SystemColors.ButtonFace;
            button1.Location = new Point(1023, 633);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(181, 45);
            button1.TabIndex = 11;
            button1.Text = "Add new";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button3
            // 
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Image = (Image)resources.GetObject("button3.Image");
            button3.Location = new Point(950, 633);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(50, 45);
            button3.TabIndex = 13;
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // ManageUserAccount
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(29, 29, 43);
            ClientSize = new Size(1355, 876);
            Controls.Add(roundedPanel1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "ManageUserAccount";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ManageUserAccount";
            roundedPanel1.ResumeLayout(false);
            roundedPanel1.PerformLayout();
            roundedPanel2.ResumeLayout(false);
            roundedPanel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private RoundedPanel roundedPanel1;
        private Panel panel1;
        private Button button1;
        private Button button3;
        private Button button4;
        private RoundedPanel roundedPanel2;
        private Label label3;
        private Label label4;
        private Button button7;
        private TextBox textBox1;
    }
}