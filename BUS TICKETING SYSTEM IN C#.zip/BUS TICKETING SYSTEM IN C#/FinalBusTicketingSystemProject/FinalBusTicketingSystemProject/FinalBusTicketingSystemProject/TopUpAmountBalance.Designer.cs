﻿namespace FinalBusTicketingSystemProject
{
    partial class TopUpAmountBalance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TopUpAmountBalance));
            roundedPanel1 = new RoundedPanel();
            panel2 = new Panel();
            roundedPanel3 = new RoundedPanel();
            button1 = new Button();
            button2 = new Button();
            textBox3 = new TextBox();
            label11 = new Label();
            textBox5 = new TextBox();
            label19 = new Label();
            roundedPanel8 = new RoundedPanel();
            label23 = new Label();
            button7 = new Button();
            roundedPanel6 = new RoundedPanel();
            gradientPanel3 = new GradientPanel();
            label8 = new Label();
            label4 = new Label();
            roundedPanel5 = new RoundedPanel();
            gradientPanel2 = new GradientPanel();
            label10 = new Label();
            label6 = new Label();
            roundedPanel4 = new RoundedPanel();
            gradientPanel1 = new GradientPanel();
            label2 = new Label();
            label5 = new Label();
            label7 = new Label();
            roundedPanel1.SuspendLayout();
            roundedPanel3.SuspendLayout();
            roundedPanel8.SuspendLayout();
            roundedPanel6.SuspendLayout();
            gradientPanel3.SuspendLayout();
            roundedPanel5.SuspendLayout();
            gradientPanel2.SuspendLayout();
            roundedPanel4.SuspendLayout();
            gradientPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // roundedPanel1
            // 
            roundedPanel1.BackColor = Color.FromArgb(192, 192, 255);
            roundedPanel1.Controls.Add(panel2);
            roundedPanel1.Controls.Add(roundedPanel3);
            roundedPanel1.Controls.Add(roundedPanel8);
            roundedPanel1.Controls.Add(button7);
            roundedPanel1.Controls.Add(roundedPanel6);
            roundedPanel1.Controls.Add(roundedPanel5);
            roundedPanel1.Controls.Add(roundedPanel4);
            roundedPanel1.Location = new Point(37, 69);
            roundedPanel1.Margin = new Padding(3, 4, 3, 4);
            roundedPanel1.Name = "roundedPanel1";
            roundedPanel1.Radius = 40;
            roundedPanel1.Size = new Size(1279, 757);
            roundedPanel1.TabIndex = 1;
            // 
            // panel2
            // 
            panel2.Location = new Point(61, 163);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(527, 24);
            panel2.TabIndex = 131;
            // 
            // roundedPanel3
            // 
            roundedPanel3.BackColor = Color.White;
            roundedPanel3.Controls.Add(button1);
            roundedPanel3.Controls.Add(button2);
            roundedPanel3.Controls.Add(textBox3);
            roundedPanel3.Controls.Add(label11);
            roundedPanel3.Controls.Add(textBox5);
            roundedPanel3.Controls.Add(label19);
            roundedPanel3.Location = new Point(61, 179);
            roundedPanel3.Margin = new Padding(3, 4, 3, 4);
            roundedPanel3.Name = "roundedPanel3";
            roundedPanel3.Radius = 20;
            roundedPanel3.Size = new Size(527, 433);
            roundedPanel3.TabIndex = 130;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(27, 26, 40);
            button1.FlatStyle = FlatStyle.Popup;
            button1.ForeColor = Color.White;
            button1.Location = new Point(299, 337);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(176, 51);
            button1.TabIndex = 128;
            button1.Text = "Add";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(27, 26, 40);
            button2.FlatStyle = FlatStyle.Popup;
            button2.ForeColor = Color.White;
            button2.Location = new Point(51, 339);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(176, 51);
            button2.TabIndex = 129;
            button2.Text = "CLEAR ALL";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.LightGray;
            textBox3.BorderStyle = BorderStyle.None;
            textBox3.Font = new Font("Segoe UI", 16.2F);
            textBox3.Location = new Point(137, 117);
            textBox3.Margin = new Padding(3, 4, 3, 4);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(321, 36);
            textBox3.TabIndex = 62;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Calibri", 9F);
            label11.ForeColor = SystemColors.ActiveCaptionText;
            label11.Location = new Point(55, 117);
            label11.Name = "label11";
            label11.Size = new Size(66, 18);
            label11.TabIndex = 63;
            label11.Text = "RFID no. :";
            // 
            // textBox5
            // 
            textBox5.BackColor = Color.LightGray;
            textBox5.BorderStyle = BorderStyle.None;
            textBox5.Font = new Font("Segoe UI", 16.2F);
            textBox5.Location = new Point(137, 173);
            textBox5.Margin = new Padding(3, 4, 3, 4);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(321, 36);
            textBox5.TabIndex = 66;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Calibri", 9F);
            label19.ForeColor = SystemColors.ActiveCaptionText;
            label19.Location = new Point(37, 173);
            label19.Name = "label19";
            label19.Size = new Size(58, 18);
            label19.TabIndex = 67;
            label19.Text = "Amount";
            // 
            // roundedPanel8
            // 
            roundedPanel8.BackColor = Color.FromArgb(255, 193, 58);
            roundedPanel8.Controls.Add(label23);
            roundedPanel8.Location = new Point(61, 116);
            roundedPanel8.Margin = new Padding(3, 4, 3, 4);
            roundedPanel8.Name = "roundedPanel8";
            roundedPanel8.Radius = 20;
            roundedPanel8.Size = new Size(527, 55);
            roundedPanel8.TabIndex = 132;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.BackColor = Color.FromArgb(255, 193, 58);
            label23.Font = new Font("Segoe UI Variable Display", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label23.ForeColor = Color.Black;
            label23.Location = new Point(31, 11);
            label23.Name = "label23";
            label23.Size = new Size(202, 36);
            label23.TabIndex = 59;
            label23.Text = "ADD AMOUNT";
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(192, 192, 255);
            button7.FlatAppearance.BorderSize = 0;
            button7.FlatStyle = FlatStyle.Flat;
            button7.ForeColor = SystemColors.ButtonFace;
            button7.Image = (Image)resources.GetObject("button7.Image");
            button7.Location = new Point(-2, 3);
            button7.Margin = new Padding(3, 4, 3, 4);
            button7.Name = "button7";
            button7.Size = new Size(77, 57);
            button7.TabIndex = 127;
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // roundedPanel6
            // 
            roundedPanel6.Controls.Add(gradientPanel3);
            roundedPanel6.Location = new Point(942, 439);
            roundedPanel6.Margin = new Padding(3, 4, 3, 4);
            roundedPanel6.Name = "roundedPanel6";
            roundedPanel6.Radius = 40;
            roundedPanel6.Size = new Size(254, 172);
            roundedPanel6.TabIndex = 126;
            // 
            // gradientPanel3
            // 
            gradientPanel3.BackColor = Color.Transparent;
            gradientPanel3.ColorBottom = Color.Silver;
            gradientPanel3.ColorTop = Color.FromArgb(224, 224, 224);
            gradientPanel3.Controls.Add(label8);
            gradientPanel3.Controls.Add(label4);
            gradientPanel3.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            gradientPanel3.Location = new Point(0, -16);
            gradientPanel3.Margin = new Padding(3, 4, 3, 4);
            gradientPanel3.Name = "gradientPanel3";
            gradientPanel3.Size = new Size(254, 189);
            gradientPanel3.TabIndex = 0;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Calibri", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.ActiveCaptionText;
            label8.Location = new Point(37, 84);
            label8.Name = "label8";
            label8.Size = new Size(92, 45);
            label8.TabIndex = 30;
            label8.Text = "****";
            label8.Click += label8_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Calibri", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.GrayText;
            label4.Location = new Point(21, 41);
            label4.Name = "label4";
            label4.Size = new Size(216, 23);
            label4.TabIndex = 29;
            label4.Text = "FINAL AMOUNT BALANCE";
            // 
            // roundedPanel5
            // 
            roundedPanel5.Controls.Add(gradientPanel2);
            roundedPanel5.Location = new Point(641, 439);
            roundedPanel5.Margin = new Padding(3, 4, 3, 4);
            roundedPanel5.Name = "roundedPanel5";
            roundedPanel5.Radius = 40;
            roundedPanel5.Size = new Size(249, 172);
            roundedPanel5.TabIndex = 125;
            // 
            // gradientPanel2
            // 
            gradientPanel2.BackColor = Color.Transparent;
            gradientPanel2.ColorBottom = Color.Silver;
            gradientPanel2.ColorTop = Color.FromArgb(224, 224, 224);
            gradientPanel2.Controls.Add(label10);
            gradientPanel2.Controls.Add(label6);
            gradientPanel2.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            gradientPanel2.Location = new Point(0, -16);
            gradientPanel2.Margin = new Padding(3, 4, 3, 4);
            gradientPanel2.Name = "gradientPanel2";
            gradientPanel2.Size = new Size(249, 189);
            gradientPanel2.TabIndex = 0;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Calibri", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = SystemColors.ActiveCaptionText;
            label10.Location = new Point(34, 85);
            label10.Name = "label10";
            label10.Size = new Size(92, 45);
            label10.TabIndex = 29;
            label10.Text = "****";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Calibri", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.GrayText;
            label6.Location = new Point(34, 41);
            label6.Name = "label6";
            label6.Size = new Size(176, 23);
            label6.TabIndex = 28;
            label6.Text = "RECHARGE AMOUNT";
            // 
            // roundedPanel4
            // 
            roundedPanel4.Controls.Add(gradientPanel1);
            roundedPanel4.Location = new Point(641, 116);
            roundedPanel4.Margin = new Padding(3, 4, 3, 4);
            roundedPanel4.Name = "roundedPanel4";
            roundedPanel4.Radius = 40;
            roundedPanel4.Size = new Size(554, 285);
            roundedPanel4.TabIndex = 124;
            // 
            // gradientPanel1
            // 
            gradientPanel1.BackColor = Color.Transparent;
            gradientPanel1.ColorBottom = Color.FromArgb(117, 110, 202);
            gradientPanel1.ColorTop = Color.FromArgb(178, 156, 250);
            gradientPanel1.Controls.Add(label2);
            gradientPanel1.Controls.Add(label5);
            gradientPanel1.Controls.Add(label7);
            gradientPanel1.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            gradientPanel1.Location = new Point(0, -16);
            gradientPanel1.Margin = new Padding(3, 4, 3, 4);
            gradientPanel1.Name = "gradientPanel1";
            gradientPanel1.Size = new Size(563, 301);
            gradientPanel1.TabIndex = 0;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Calibri", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ButtonFace;
            label2.Location = new Point(56, 196);
            label2.Name = "label2";
            label2.Size = new Size(226, 45);
            label2.TabIndex = 30;
            label2.Text = "**** *. *****";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Calibri", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(56, 95);
            label5.Name = "label5";
            label5.Size = new Size(218, 45);
            label5.TabIndex = 24;
            label5.Text = "***********";
            label5.Click += label5_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Calibri", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ButtonFace;
            label7.Location = new Point(56, 63);
            label7.Name = "label7";
            label7.Size = new Size(132, 23);
            label7.TabIndex = 26;
            label7.Text = "CARD NUMBER";
            // 
            // TopUpAmountBalance
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(29, 29, 43);
            ClientSize = new Size(1355, 876);
            Controls.Add(roundedPanel1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "TopUpAmountBalance";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "TopUpAmountBalance";
            roundedPanel1.ResumeLayout(false);
            roundedPanel3.ResumeLayout(false);
            roundedPanel3.PerformLayout();
            roundedPanel8.ResumeLayout(false);
            roundedPanel8.PerformLayout();
            roundedPanel6.ResumeLayout(false);
            gradientPanel3.ResumeLayout(false);
            gradientPanel3.PerformLayout();
            roundedPanel5.ResumeLayout(false);
            gradientPanel2.ResumeLayout(false);
            gradientPanel2.PerformLayout();
            roundedPanel4.ResumeLayout(false);
            gradientPanel1.ResumeLayout(false);
            gradientPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private RoundedPanel roundedPanel1;
        private Button button2;
        private Button button1;
        private RoundedPanel roundedPanel6;
        private GradientPanel gradientPanel3;
        private RoundedPanel roundedPanel5;
        private GradientPanel gradientPanel2;
        private RoundedPanel roundedPanel4;
        private GradientPanel gradientPanel1;
        private Label label2;
        private Label label5;
        private Label label7;
        private Label label8;
        private Label label4;
        private Label label10;
        private Label label6;
        private Button button7;
        private Panel panel2;
        private RoundedPanel roundedPanel3;
        private TextBox textBox3;
        private Label label11;
        private TextBox textBox5;
        private Label label19;
        private RoundedPanel roundedPanel8;
        private Label label23;
    }
}