﻿namespace FinalBusTicketingSystemProject
{
    partial class LookAtUserAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LookAtUserAccount));
            roundedPanel1 = new RoundedPanel();
            button7 = new Button();
            panel1 = new Panel();
            label10 = new Label();
            roundedPanel2 = new RoundedPanel();
            gradientPanel1 = new GradientPanel();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label9 = new Label();
            label8 = new Label();
            roundedPanel3 = new RoundedPanel();
            gradientPanel2 = new GradientPanel();
            label3 = new Label();
            label2 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label1 = new Label();
            roundedPanel1.SuspendLayout();
            roundedPanel2.SuspendLayout();
            gradientPanel1.SuspendLayout();
            roundedPanel3.SuspendLayout();
            gradientPanel2.SuspendLayout();
            SuspendLayout();
            // 
            // roundedPanel1
            // 
            roundedPanel1.BackColor = Color.FromArgb(192, 192, 255);
            roundedPanel1.Controls.Add(button7);
            roundedPanel1.Controls.Add(panel1);
            roundedPanel1.Controls.Add(label10);
            roundedPanel1.Controls.Add(roundedPanel2);
            roundedPanel1.Location = new Point(37, 69);
            roundedPanel1.Margin = new Padding(3, 4, 3, 4);
            roundedPanel1.Name = "roundedPanel1";
            roundedPanel1.Radius = 40;
            roundedPanel1.Size = new Size(1262, 757);
            roundedPanel1.TabIndex = 0;
            roundedPanel1.Paint += roundedPanel1_Paint;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(192, 192, 255);
            button7.FlatAppearance.BorderSize = 0;
            button7.FlatStyle = FlatStyle.Flat;
            button7.ForeColor = SystemColors.ButtonFace;
            button7.Image = (Image)resources.GetObject("button7.Image");
            button7.Location = new Point(0, 0);
            button7.Margin = new Padding(3, 4, 3, 4);
            button7.Name = "button7";
            button7.Size = new Size(77, 64);
            button7.TabIndex = 128;
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(224, 224, 224);
            panel1.Location = new Point(49, 435);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1157, 291);
            panel1.TabIndex = 14;
            panel1.Paint += panel1_Paint;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Microsoft YaHei", 11.25F);
            label10.ForeColor = SystemColors.ActiveCaptionText;
            label10.Location = new Point(49, 391);
            label10.Name = "label10";
            label10.Size = new Size(161, 25);
            label10.TabIndex = 12;
            label10.Text = "Tracking History";
            // 
            // roundedPanel2
            // 
            roundedPanel2.BackColor = Color.White;
            roundedPanel2.Controls.Add(gradientPanel1);
            roundedPanel2.Location = new Point(49, 72);
            roundedPanel2.Margin = new Padding(3, 4, 3, 4);
            roundedPanel2.Name = "roundedPanel2";
            roundedPanel2.Radius = 30;
            roundedPanel2.Size = new Size(1157, 293);
            roundedPanel2.TabIndex = 9;
            // 
            // gradientPanel1
            // 
            gradientPanel1.ColorBottom = Color.FromArgb(119, 112, 207);
            gradientPanel1.ColorTop = Color.FromArgb(182, 160, 255);
            gradientPanel1.Controls.Add(label14);
            gradientPanel1.Controls.Add(label13);
            gradientPanel1.Controls.Add(label12);
            gradientPanel1.Controls.Add(label11);
            gradientPanel1.Controls.Add(label9);
            gradientPanel1.Controls.Add(label8);
            gradientPanel1.Controls.Add(roundedPanel3);
            gradientPanel1.Controls.Add(label7);
            gradientPanel1.Controls.Add(label6);
            gradientPanel1.Controls.Add(label5);
            gradientPanel1.Controls.Add(label4);
            gradientPanel1.Controls.Add(label1);
            gradientPanel1.Location = new Point(-10, -3);
            gradientPanel1.Margin = new Padding(3, 4, 3, 4);
            gradientPanel1.Name = "gradientPanel1";
            gradientPanel1.Size = new Size(1167, 296);
            gradientPanel1.TabIndex = 8;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.Transparent;
            label14.Font = new Font("Microsoft YaHei", 11.25F);
            label14.ForeColor = SystemColors.ButtonHighlight;
            label14.Location = new Point(523, 248);
            label14.Name = "label14";
            label14.Size = new Size(102, 25);
            label14.TabIndex = 15;
            label14.Text = "**********";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.Font = new Font("Microsoft YaHei", 11.25F);
            label13.ForeColor = SystemColors.ButtonHighlight;
            label13.Location = new Point(523, 204);
            label13.Name = "label13";
            label13.Size = new Size(102, 25);
            label13.TabIndex = 14;
            label13.Text = "**********";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Microsoft YaHei", 11.25F);
            label12.ForeColor = SystemColors.ButtonHighlight;
            label12.Location = new Point(523, 166);
            label12.Name = "label12";
            label12.Size = new Size(102, 25);
            label12.TabIndex = 13;
            label12.Text = "**********";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Transparent;
            label11.Font = new Font("Microsoft YaHei", 11.25F);
            label11.ForeColor = SystemColors.ButtonHighlight;
            label11.Location = new Point(523, 125);
            label11.Name = "label11";
            label11.Size = new Size(102, 25);
            label11.TabIndex = 12;
            label11.Text = "**********";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Microsoft YaHei", 11.25F);
            label9.ForeColor = SystemColors.ButtonHighlight;
            label9.Location = new Point(393, 248);
            label9.Name = "label9";
            label9.Size = new Size(124, 25);
            label9.TabIndex = 10;
            label9.Text = "Civil Status :";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Microsoft YaHei", 11.25F);
            label8.ForeColor = SystemColors.ButtonHighlight;
            label8.Location = new Point(418, 204);
            label8.Name = "label8";
            label8.Size = new Size(99, 25);
            label8.TabIndex = 9;
            label8.Text = "Birthday :";
            // 
            // roundedPanel3
            // 
            roundedPanel3.BackColor = Color.White;
            roundedPanel3.Controls.Add(gradientPanel2);
            roundedPanel3.Location = new Point(772, 17);
            roundedPanel3.Margin = new Padding(3, 4, 3, 4);
            roundedPanel3.Name = "roundedPanel3";
            roundedPanel3.Radius = 30;
            roundedPanel3.Size = new Size(376, 87);
            roundedPanel3.TabIndex = 11;
            // 
            // gradientPanel2
            // 
            gradientPanel2.ColorBottom = Color.FromArgb(192, 192, 255);
            gradientPanel2.ColorTop = Color.FromArgb(224, 224, 224);
            gradientPanel2.Controls.Add(label3);
            gradientPanel2.Controls.Add(label2);
            gradientPanel2.Location = new Point(-4, -2);
            gradientPanel2.Margin = new Padding(3, 4, 3, 4);
            gradientPanel2.Name = "gradientPanel2";
            gradientPanel2.Size = new Size(380, 100);
            gradientPanel2.TabIndex = 10;
            gradientPanel2.Paint += gradientPanel2_Paint;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("MS Reference Sans Serif", 9.75F);
            label3.ForeColor = SystemColors.GrayText;
            label3.Location = new Point(24, 13);
            label3.Name = "label3";
            label3.Size = new Size(171, 22);
            label3.TabIndex = 4;
            label3.Text = "AMOUNT BALANCE";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Microsoft Tai Le", 20.25F, FontStyle.Bold);
            label2.Location = new Point(24, 35);
            label2.Name = "label2";
            label2.Size = new Size(99, 44);
            label2.TabIndex = 3;
            label2.Text = "$100";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Microsoft YaHei", 11.25F);
            label7.ForeColor = SystemColors.ButtonHighlight;
            label7.Location = new Point(366, 164);
            label7.Name = "label7";
            label7.Size = new Size(151, 25);
            label7.TabIndex = 8;
            label7.Text = "Email Address :";
            label7.Click += label7_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Microsoft YaHei", 11.25F);
            label6.ForeColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(400, 125);
            label6.Name = "label6";
            label6.Size = new Size(117, 25);
            label6.TabIndex = 6;
            label6.Text = "Phone no. :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Microsoft YaHei", 20.25F, FontStyle.Bold);
            label5.ForeColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(51, 28);
            label5.Name = "label5";
            label5.Size = new Size(321, 45);
            label5.TabIndex = 5;
            label5.Text = "Julianne P. Bullen";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Microsoft YaHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(51, 125);
            label4.Name = "label4";
            label4.Size = new Size(185, 39);
            label4.TabIndex = 4;
            label4.Text = "************";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Microsoft YaHei", 11.25F);
            label1.ForeColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(51, 90);
            label1.Name = "label1";
            label1.Size = new Size(152, 25);
            label1.TabIndex = 3;
            label1.Text = "CARD NUMBER";
            // 
            // LookAtUserAccount
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(29, 29, 43);
            ClientSize = new Size(1355, 876);
            Controls.Add(roundedPanel1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "LookAtUserAccount";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ManageUsers";
            roundedPanel1.ResumeLayout(false);
            roundedPanel1.PerformLayout();
            roundedPanel2.ResumeLayout(false);
            gradientPanel1.ResumeLayout(false);
            gradientPanel1.PerformLayout();
            roundedPanel3.ResumeLayout(false);
            gradientPanel2.ResumeLayout(false);
            gradientPanel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private RoundedPanel roundedPanel1;
        private GradientPanel gradientPanel1;
        private RoundedPanel roundedPanel3;
        private GradientPanel gradientPanel2;
        private Label label2;
        private RoundedPanel roundedPanel2;
        private Label label3;
        private Label label5;
        private Label label6;
        private Label label4;
        private Label label7;
        private Label label9;
        private Label label8;
        private Label label10;
        private Panel panel1;
        private Button button7;
        private Label label11;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label1;
    }
}