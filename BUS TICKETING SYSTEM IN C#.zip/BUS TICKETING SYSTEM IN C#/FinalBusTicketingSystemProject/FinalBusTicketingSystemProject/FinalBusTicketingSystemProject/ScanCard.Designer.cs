﻿namespace FinalBusTicketingSystemProject
{
    partial class ScanCard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ScanCard));
            roundedPanel1 = new RoundedPanel();
            label19 = new Label();
            panel3 = new Panel();
            label21 = new Label();
            button1 = new Button();
            label20 = new Label();
            pictureBox2 = new PictureBox();
            comboBox1 = new ComboBox();
            label18 = new Label();
            textBox2 = new TextBox();
            roundedPanel8 = new RoundedPanel();
            label17 = new Label();
            label3 = new Label();
            label8 = new Label();
            label4 = new Label();
            label15 = new Label();
            label14 = new Label();
            label16 = new Label();
            button7 = new Button();
            roundedPanel7 = new RoundedPanel();
            gradientPanel5 = new GradientPanel();
            label12 = new Label();
            label9 = new Label();
            roundedPanel6 = new RoundedPanel();
            gradientPanel4 = new GradientPanel();
            label13 = new Label();
            label11 = new Label();
            roundedPanel5 = new RoundedPanel();
            gradientPanel3 = new GradientPanel();
            label10 = new Label();
            label6 = new Label();
            roundedPanel2 = new RoundedPanel();
            gradientPanel1 = new GradientPanel();
            pictureBox1 = new PictureBox();
            label2 = new Label();
            label1 = new Label();
            label5 = new Label();
            label7 = new Label();
            roundedPanel3 = new RoundedPanel();
            gradientPanel2 = new GradientPanel();
            roundedPanel4 = new RoundedPanel();
            gradientPanel6 = new GradientPanel();
            panel1 = new Panel();
            roundedPanel1.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            roundedPanel8.SuspendLayout();
            roundedPanel7.SuspendLayout();
            gradientPanel5.SuspendLayout();
            roundedPanel6.SuspendLayout();
            gradientPanel4.SuspendLayout();
            roundedPanel5.SuspendLayout();
            gradientPanel3.SuspendLayout();
            roundedPanel2.SuspendLayout();
            gradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            roundedPanel3.SuspendLayout();
            roundedPanel4.SuspendLayout();
            SuspendLayout();
            // 
            // roundedPanel1
            // 
            roundedPanel1.BackColor = Color.FromArgb(192, 192, 255);
            roundedPanel1.Controls.Add(label19);
            roundedPanel1.Controls.Add(panel3);
            roundedPanel1.Controls.Add(comboBox1);
            roundedPanel1.Controls.Add(label18);
            roundedPanel1.Controls.Add(textBox2);
            roundedPanel1.Controls.Add(roundedPanel8);
            roundedPanel1.Controls.Add(button7);
            roundedPanel1.Controls.Add(roundedPanel7);
            roundedPanel1.Controls.Add(roundedPanel6);
            roundedPanel1.Controls.Add(roundedPanel5);
            roundedPanel1.Controls.Add(roundedPanel2);
            roundedPanel1.Controls.Add(roundedPanel3);
            roundedPanel1.Controls.Add(roundedPanel4);
            roundedPanel1.Location = new Point(37, 69);
            roundedPanel1.Margin = new Padding(3, 4, 3, 4);
            roundedPanel1.Name = "roundedPanel1";
            roundedPanel1.Radius = 40;
            roundedPanel1.Size = new Size(1279, 757);
            roundedPanel1.TabIndex = 1;
            roundedPanel1.Paint += roundedPanel1_Paint;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Calibri", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label19.ForeColor = Color.Black;
            label19.Location = new Point(59, 170);
            label19.Name = "label19";
            label19.Size = new Size(88, 18);
            label19.TabIndex = 137;
            label19.Text = "Select a bus :";
            // 
            // panel3
            // 
            panel3.BackColor = Color.WhiteSmoke;
            panel3.BorderStyle = BorderStyle.FixedSingle;
            panel3.Controls.Add(label21);
            panel3.Controls.Add(button1);
            panel3.Controls.Add(label20);
            panel3.Controls.Add(pictureBox2);
            panel3.Location = new Point(392, 223);
            panel3.Name = "panel3";
            panel3.Size = new Size(584, 290);
            panel3.TabIndex = 33;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label21.ForeColor = Color.Black;
            label21.Location = new Point(51, 104);
            label21.Name = "label21";
            label21.Size = new Size(477, 56);
            label21.TabIndex = 0;
            label21.Text = "No active booking found for the scanned RFID on the\r\n selected bus or bus name does not match.";
            // 
            // button1
            // 
            button1.ForeColor = Color.Black;
            button1.Location = new Point(432, 235);
            button1.Name = "button1";
            button1.Size = new Size(135, 40);
            button1.TabIndex = 2;
            button1.Text = "OK";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.BackColor = Color.Transparent;
            label20.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label20.ForeColor = Color.Black;
            label20.Location = new Point(54, 14);
            label20.Name = "label20";
            label20.Size = new Size(108, 37);
            label20.TabIndex = 1;
            label20.Text = "ERROR";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(48, 62);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // comboBox1
            // 
            comboBox1.BackColor = Color.FromArgb(192, 192, 255);
            comboBox1.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox1.FormattingEnabled = true;
            comboBox1.ItemHeight = 25;
            comboBox1.Items.AddRange(new object[] { "Victory Liner -  TYR 123", "Genesis Transport - ABC 456", "Ceres Liner - XYZ 789", "Philtranco - LMN 321", "Dimple Star Transport - DEF 654" });
            comboBox1.Location = new Point(59, 195);
            comboBox1.Margin = new Padding(3, 4, 3, 4);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(380, 33);
            comboBox1.TabIndex = 138;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Calibri", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label18.ForeColor = SystemColors.ActiveCaptionText;
            label18.Location = new Point(75, 80);
            label18.Name = "label18";
            label18.Size = new Size(125, 21);
            label18.TabIndex = 27;
            label18.Text = "TAP YOUR CARD";
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.FromArgb(192, 192, 255);
            textBox2.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox2.Location = new Point(56, 91);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(383, 47);
            textBox2.TabIndex = 129;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // roundedPanel8
            // 
            roundedPanel8.BackColor = Color.WhiteSmoke;
            roundedPanel8.Controls.Add(label17);
            roundedPanel8.Controls.Add(label3);
            roundedPanel8.Controls.Add(label8);
            roundedPanel8.Controls.Add(label4);
            roundedPanel8.Controls.Add(label15);
            roundedPanel8.Controls.Add(label14);
            roundedPanel8.Controls.Add(label16);
            roundedPanel8.Location = new Point(55, 240);
            roundedPanel8.Margin = new Padding(3, 4, 3, 4);
            roundedPanel8.Name = "roundedPanel8";
            roundedPanel8.Radius = 20;
            roundedPanel8.Size = new Size(384, 328);
            roundedPanel8.TabIndex = 127;
            roundedPanel8.Paint += roundedPanel8_Paint;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.BackColor = Color.Transparent;
            label17.Font = new Font("Microsoft YaHei", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label17.ForeColor = SystemColors.ActiveCaptionText;
            label17.Location = new Point(61, 237);
            label17.Name = "label17";
            label17.Size = new Size(256, 27);
            label17.TabIndex = 28;
            label17.Text = "********, *******, *******";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Microsoft YaHei", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ActiveCaptionText;
            label3.Location = new Point(61, 88);
            label3.Name = "label3";
            label3.Size = new Size(235, 27);
            label3.TabIndex = 22;
            label3.Text = "Tagbilaran City, Bohol";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Candara", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.ControlDarkDark;
            label8.Location = new Point(33, 40);
            label8.Name = "label8";
            label8.Size = new Size(26, 29);
            label8.TabIndex = 24;
            label8.Text = "o\r\n";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Calibri", 13.8F);
            label4.ForeColor = SystemColors.ControlDarkDark;
            label4.Location = new Point(63, 45);
            label4.Name = "label4";
            label4.Size = new Size(107, 28);
            label4.TabIndex = 23;
            label4.Text = "Departure";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Candara", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label15.ForeColor = Color.RoyalBlue;
            label15.Location = new Point(34, 185);
            label15.Name = "label15";
            label15.Size = new Size(26, 29);
            label15.TabIndex = 26;
            label15.Text = "o\r\n";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Candara", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label14.ForeColor = SystemColors.ControlDarkDark;
            label14.Location = new Point(37, 65);
            label14.Name = "label14";
            label14.Size = new Size(19, 116);
            label14.TabIndex = 25;
            label14.Text = ".\r\n.\r\n.\r\n.";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Calibri", 13.8F);
            label16.ForeColor = SystemColors.ControlDarkDark;
            label16.Location = new Point(65, 185);
            label16.Name = "label16";
            label16.Size = new Size(119, 28);
            label16.TabIndex = 27;
            label16.Text = "Destination";
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(192, 192, 255);
            button7.FlatAppearance.BorderSize = 0;
            button7.FlatStyle = FlatStyle.Flat;
            button7.ForeColor = SystemColors.ButtonFace;
            button7.Image = (Image)resources.GetObject("button7.Image");
            button7.Location = new Point(-8, 0);
            button7.Margin = new Padding(3, 4, 3, 4);
            button7.Name = "button7";
            button7.Size = new Size(77, 57);
            button7.TabIndex = 126;
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // roundedPanel7
            // 
            roundedPanel7.Controls.Add(gradientPanel5);
            roundedPanel7.Location = new Point(950, 541);
            roundedPanel7.Margin = new Padding(3, 4, 3, 4);
            roundedPanel7.Name = "roundedPanel7";
            roundedPanel7.Radius = 40;
            roundedPanel7.Size = new Size(217, 171);
            roundedPanel7.TabIndex = 21;
            // 
            // gradientPanel5
            // 
            gradientPanel5.ColorBottom = Color.Silver;
            gradientPanel5.ColorTop = Color.FromArgb(224, 224, 224);
            gradientPanel5.Controls.Add(label12);
            gradientPanel5.Controls.Add(label9);
            gradientPanel5.Location = new Point(-5, -9);
            gradientPanel5.Margin = new Padding(3, 4, 3, 4);
            gradientPanel5.Name = "gradientPanel5";
            gradientPanel5.Size = new Size(243, 184);
            gradientPanel5.TabIndex = 18;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Calibri", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.ForeColor = SystemColors.GrayText;
            label12.Location = new Point(27, 33);
            label12.Name = "label12";
            label12.Size = new Size(87, 23);
            label12.TabIndex = 26;
            label12.Text = "PAYMENT";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Calibri", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.Black;
            label9.Location = new Point(27, 77);
            label9.Name = "label9";
            label9.Size = new Size(92, 45);
            label9.TabIndex = 28;
            label9.Text = "****";
            // 
            // roundedPanel6
            // 
            roundedPanel6.Controls.Add(gradientPanel4);
            roundedPanel6.Location = new Point(704, 541);
            roundedPanel6.Margin = new Padding(3, 4, 3, 4);
            roundedPanel6.Name = "roundedPanel6";
            roundedPanel6.Radius = 40;
            roundedPanel6.Size = new Size(234, 175);
            roundedPanel6.TabIndex = 20;
            // 
            // gradientPanel4
            // 
            gradientPanel4.ColorBottom = Color.Silver;
            gradientPanel4.ColorTop = Color.FromArgb(224, 224, 224);
            gradientPanel4.Controls.Add(label13);
            gradientPanel4.Controls.Add(label11);
            gradientPanel4.Location = new Point(-6, -9);
            gradientPanel4.Margin = new Padding(3, 4, 3, 4);
            gradientPanel4.Name = "gradientPanel4";
            gradientPanel4.Size = new Size(243, 209);
            gradientPanel4.TabIndex = 18;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.Font = new Font("Calibri", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.ForeColor = SystemColors.ActiveCaptionText;
            label13.Location = new Point(27, 77);
            label13.Name = "label13";
            label13.Size = new Size(110, 45);
            label13.TabIndex = 28;
            label13.Text = "*****";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Transparent;
            label11.Font = new Font("Calibri", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.ForeColor = SystemColors.GrayText;
            label11.Location = new Point(27, 33);
            label11.Name = "label11";
            label11.Size = new Size(164, 23);
            label11.TabIndex = 26;
            label11.Text = "CURRENT BALANCE";
            // 
            // roundedPanel5
            // 
            roundedPanel5.Controls.Add(gradientPanel3);
            roundedPanel5.Location = new Point(470, 541);
            roundedPanel5.Margin = new Padding(3, 4, 3, 4);
            roundedPanel5.Name = "roundedPanel5";
            roundedPanel5.Radius = 40;
            roundedPanel5.Size = new Size(222, 171);
            roundedPanel5.TabIndex = 19;
            // 
            // gradientPanel3
            // 
            gradientPanel3.ColorBottom = Color.Silver;
            gradientPanel3.ColorTop = Color.FromArgb(224, 224, 224);
            gradientPanel3.Controls.Add(label10);
            gradientPanel3.Controls.Add(label6);
            gradientPanel3.Location = new Point(-6, -9);
            gradientPanel3.Margin = new Padding(3, 4, 3, 4);
            gradientPanel3.Name = "gradientPanel3";
            gradientPanel3.Size = new Size(229, 183);
            gradientPanel3.TabIndex = 18;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Calibri", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = SystemColors.ActiveCaptionText;
            label10.Location = new Point(27, 77);
            label10.Name = "label10";
            label10.Size = new Size(74, 45);
            label10.TabIndex = 27;
            label10.Text = "***";
            label10.Click += label10_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Calibri", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.GrayText;
            label6.Location = new Point(27, 33);
            label6.Name = "label6";
            label6.Size = new Size(174, 23);
            label6.TabIndex = 25;
            label6.Text = "NO. OF SEATS TAKEN";
            // 
            // roundedPanel2
            // 
            roundedPanel2.Controls.Add(gradientPanel1);
            roundedPanel2.Location = new Point(470, 49);
            roundedPanel2.Margin = new Padding(3, 4, 3, 4);
            roundedPanel2.Name = "roundedPanel2";
            roundedPanel2.Radius = 40;
            roundedPanel2.Size = new Size(719, 455);
            roundedPanel2.TabIndex = 15;
            // 
            // gradientPanel1
            // 
            gradientPanel1.BackColor = Color.Transparent;
            gradientPanel1.ColorBottom = Color.FromArgb(110, 98, 191);
            gradientPanel1.ColorTop = Color.FromArgb(178, 156, 250);
            gradientPanel1.Controls.Add(pictureBox1);
            gradientPanel1.Controls.Add(label2);
            gradientPanel1.Controls.Add(label1);
            gradientPanel1.Controls.Add(label5);
            gradientPanel1.Controls.Add(label7);
            gradientPanel1.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            gradientPanel1.Location = new Point(-6, -16);
            gradientPanel1.Margin = new Padding(3, 4, 3, 4);
            gradientPanel1.Name = "gradientPanel1";
            gradientPanel1.Size = new Size(725, 491);
            gradientPanel1.TabIndex = 0;
            gradientPanel1.Paint += gradientPanel1_Paint;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(166, 40);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(41, 67);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 31;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Calibri", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ButtonFace;
            label2.Location = new Point(62, 352);
            label2.Name = "label2";
            label2.Size = new Size(359, 58);
            label2.TabIndex = 30;
            label2.Text = "***** *. *******";
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Century", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.MediumBlue;
            label1.Location = new Point(48, 47);
            label1.Name = "label1";
            label1.Size = new Size(127, 47);
            label1.TabIndex = 29;
            label1.Text = "RFID";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Calibri", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(62, 196);
            label5.Name = "label5";
            label5.Size = new Size(218, 45);
            label5.TabIndex = 24;
            label5.Text = "***********";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Calibri", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ButtonFace;
            label7.Location = new Point(62, 164);
            label7.Name = "label7";
            label7.Size = new Size(132, 23);
            label7.TabIndex = 26;
            label7.Text = "CARD NUMBER";
            // 
            // roundedPanel3
            // 
            roundedPanel3.BackColor = Color.FromArgb(178, 126, 198);
            roundedPanel3.Controls.Add(gradientPanel2);
            roundedPanel3.Location = new Point(781, 96);
            roundedPanel3.Margin = new Padding(3, 4, 3, 4);
            roundedPanel3.Name = "roundedPanel3";
            roundedPanel3.Radius = 40;
            roundedPanel3.Size = new Size(430, 361);
            roundedPanel3.TabIndex = 16;
            // 
            // gradientPanel2
            // 
            gradientPanel2.ColorBottom = Color.FromArgb(171, 113, 189);
            gradientPanel2.ColorTop = Color.FromArgb(202, 162, 224);
            gradientPanel2.Location = new Point(0, -4);
            gradientPanel2.Margin = new Padding(3, 4, 3, 4);
            gradientPanel2.Name = "gradientPanel2";
            gradientPanel2.Size = new Size(430, 365);
            gradientPanel2.TabIndex = 0;
            // 
            // roundedPanel4
            // 
            roundedPanel4.BackColor = Color.FromArgb(178, 126, 198);
            roundedPanel4.Controls.Add(gradientPanel6);
            roundedPanel4.Location = new Point(903, 147);
            roundedPanel4.Margin = new Padding(3, 4, 3, 4);
            roundedPanel4.Name = "roundedPanel4";
            roundedPanel4.Radius = 40;
            roundedPanel4.Size = new Size(327, 259);
            roundedPanel4.TabIndex = 130;
            // 
            // gradientPanel6
            // 
            gradientPanel6.ColorBottom = Color.FromArgb(204, 181, 179);
            gradientPanel6.ColorTop = Color.FromArgb(240, 213, 211);
            gradientPanel6.Location = new Point(0, 0);
            gradientPanel6.Margin = new Padding(3, 4, 3, 4);
            gradientPanel6.Name = "gradientPanel6";
            gradientPanel6.Size = new Size(327, 259);
            gradientPanel6.TabIndex = 0;
            // 
            // panel1
            // 
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1355, 876);
            panel1.TabIndex = 2;
            panel1.Paint += panel1_Paint;
            // 
            // ScanCard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(29, 29, 43);
            ClientSize = new Size(1355, 876);
            Controls.Add(roundedPanel1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "ScanCard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ScanCard";
            roundedPanel1.ResumeLayout(false);
            roundedPanel1.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            roundedPanel8.ResumeLayout(false);
            roundedPanel8.PerformLayout();
            roundedPanel7.ResumeLayout(false);
            gradientPanel5.ResumeLayout(false);
            gradientPanel5.PerformLayout();
            roundedPanel6.ResumeLayout(false);
            gradientPanel4.ResumeLayout(false);
            gradientPanel4.PerformLayout();
            roundedPanel5.ResumeLayout(false);
            gradientPanel3.ResumeLayout(false);
            gradientPanel3.PerformLayout();
            roundedPanel2.ResumeLayout(false);
            gradientPanel1.ResumeLayout(false);
            gradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            roundedPanel3.ResumeLayout(false);
            roundedPanel4.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private RoundedPanel roundedPanel1;
        private RoundedPanel roundedPanel2;
        private GradientPanel gradientPanel1;
        private RoundedPanel roundedPanel3;
        private GradientPanel gradientPanel2;
        private RoundedPanel roundedPanel5;
        private GradientPanel gradientPanel3;
        private RoundedPanel roundedPanel7;
        private GradientPanel gradientPanel5;
        private Label label4;
        private RoundedPanel roundedPanel6;
        private GradientPanel gradientPanel4;
        private Label label6;
        private Label label5;
        private Label label9;
        private Label label7;
        private Label label3;
        private Label label1;
        private Label label10;
        private Label label2;
        private Label label12;
        private Label label13;
        private Label label11;
        private PictureBox pictureBox1;
        private Label label14;
        private Label label8;
        private Label label16;
        private Label label15;
        private Label label18;
        private Label label17;
        private Button button7;
        private Panel panel1;
        private RoundedPanel roundedPanel8;
        private TextBox textBox2;
        private RoundedPanel roundedPanel4;
        private GradientPanel gradientPanel6;
        private Label label19;
        private ComboBox comboBox1;
        private Label label21;
        private Panel panel3;
        private Button button1;
        private Label label20;
        private PictureBox pictureBox2;
    }
}