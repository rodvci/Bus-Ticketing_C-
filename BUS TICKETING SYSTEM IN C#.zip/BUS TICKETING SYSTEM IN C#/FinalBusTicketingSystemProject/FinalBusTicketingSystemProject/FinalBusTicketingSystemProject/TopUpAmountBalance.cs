﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FinalBusTicketingSystemProject
{
    public partial class TopUpAmountBalance : Form
    {
        private string currentRFID = "";
        public TopUpAmountBalance()
        {
            InitializeComponent();
            textBox3.KeyPress += textBox3_KeyPress;
            textBox5.KeyPress += textBox3_KeyPress;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void UpdateCurrencyLabel(Label label, string amount)
        {
            if (decimal.TryParse(amount, out decimal decimalAmount))
            {
                label.Text = decimalAmount.ToString("C2", System.Globalization.CultureInfo.CreateSpecificCulture("en-US"));
            }
            else
            {
                label.Text = "Invalid amount";
            }
        }

        private void ProcessRFID()
        {
            // Process the RFID
            string scannedRFID = currentRFID;
            RFIDInfo info = ReadRFID(scannedRFID);

            if (info != null)
            {
                label2.Text = info.FullName;
                label5.Text = info.RFID;
                UpdateCurrencyLabel(label8, info.Balance); // Update label8 with formatted balance
            }
            else
            {
                label2.Text = "";
                label5.Text = "";
                label8.Text = "";
            }
        }

        private RFIDInfo ReadRFID(string scannedRFID)
        {
            string connectionString = "Server=localhost;Port=3306;Database=database;Uid=root;Pwd=";
            string query = "SELECT FirstName, MiddleInitial, LastName, RFID_Number, Balance FROM personal_information WHERE RFID_Number = @RFID";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@RFID", scannedRFID);

                    try
                    {
                        connection.Open();
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string firstName = reader["FirstName"].ToString();
                                string middleInitial = reader["MiddleInitial"].ToString();
                                string lastName = reader["LastName"].ToString();

                                // Concatenate and capitalize the full name
                                string fullName = $"{firstName.ToUpper()} {middleInitial.ToUpper()}. {lastName.ToUpper()}";

                                return new RFIDInfo
                                {

                                    FullName = fullName,
                                    RFID = reader["RFID_Number"].ToString(),
                                    Balance = reader["Balance"].ToString()
                                };
                            }
                            else
                            {
                                return null;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                        return null;
                    }
                }
            }
        }
        private class RFIDInfo
        {

            public string FullName { get; set; }
            public string RFID { get; set; }
            public string Balance { get; set; }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            // Get the value from textBox2
            if (!decimal.TryParse(textBox5.Text, out decimal amountToAdd))
            {
                MessageBox.Show("Invalid amount.");
                return;
            }

            // Show a confirmation dialog with the amount to be added
            DialogResult result = MessageBox.Show($"Are you sure you want to add {amountToAdd:C} to the balance of RFID {currentRFID}?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {

                // Update the balance in the database
                string connectionString = "Server=localhost;Port=3306;Database=database;Uid=root;Pwd=";
                string query = "UPDATE personal_information SET Balance = Balance + @AmountToAdd WHERE RFID_Number = @RFID";

                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@AmountToAdd", amountToAdd);
                        command.Parameters.AddWithValue("@RFID", currentRFID);

                        try
                        {
                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Balance updated successfully.");
                                textBox5.Text = "";
                                ProcessRFID();
                                UpdateCurrencyLabel(label10, amountToAdd.ToString());
                            }
                            else
                            {
                                MessageBox.Show("RFID not found.");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("An error occurred: " + ex.Message);
                        }
                    }
                }
            }
        }
        private void UpdateLabel10()
        {
            UpdateCurrencyLabel(label10, textBox5.Text);
        }
        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow only numeric characters and control keys
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Prevent the character from being entered
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox3.Text.Length > 10)
            {
                textBox3.Text = currentRFID;
            }

            // Check if the length of the entered RFID reaches 10 characters
            if (textBox3.Text.Length == 10)
            {
                // Process the RFID
                currentRFID = textBox3.Text; // Update currentRFID
                ProcessRFID();

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox3.Text = "";
            textBox5.Text = "";
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
