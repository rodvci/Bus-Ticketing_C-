﻿namespace FinalBusTicketingSystemProject
{
    partial class MainContainer
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainContainer));
            roundedPanel1 = new RoundedPanel();
            TopUpAmountButton = new Button();
            HomeButton = new Button();
            ScanCardButton = new Button();
            ManageBusesButton = new Button();
            ManageUserAccountButton = new Button();
            ManageBookingButton = new Button();
            panel1 = new Panel();
            button3 = new Button();
            panel2 = new Panel();
            panel3 = new Panel();
            panel4 = new Panel();
            button1 = new Button();
            button2 = new Button();
            roundedPanel1.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // roundedPanel1
            // 
            roundedPanel1.BackColor = Color.FromArgb(255, 193, 58);
            roundedPanel1.Controls.Add(button2);
            roundedPanel1.Controls.Add(TopUpAmountButton);
            roundedPanel1.Controls.Add(HomeButton);
            roundedPanel1.Controls.Add(ScanCardButton);
            roundedPanel1.Controls.Add(ManageBusesButton);
            roundedPanel1.Controls.Add(ManageUserAccountButton);
            roundedPanel1.Controls.Add(ManageBookingButton);
            roundedPanel1.Location = new Point(32, 69);
            roundedPanel1.Margin = new Padding(3, 4, 3, 4);
            roundedPanel1.Name = "roundedPanel1";
            roundedPanel1.Radius = 20;
            roundedPanel1.Size = new Size(102, 757);
            roundedPanel1.TabIndex = 13;
            // 
            // TopUpAmountButton
            // 
            TopUpAmountButton.BackColor = Color.FromArgb(255, 193, 58);
            TopUpAmountButton.FlatAppearance.BorderSize = 0;
            TopUpAmountButton.FlatStyle = FlatStyle.Flat;
            TopUpAmountButton.Font = new Font("Arial Narrow", 12F);
            TopUpAmountButton.ForeColor = Color.FromArgb(29, 29, 43);
            TopUpAmountButton.Image = (Image)resources.GetObject("TopUpAmountButton.Image");
            TopUpAmountButton.ImageAlign = ContentAlignment.TopCenter;
            TopUpAmountButton.Location = new Point(3, 359);
            TopUpAmountButton.Margin = new Padding(3, 4, 3, 4);
            TopUpAmountButton.Name = "TopUpAmountButton";
            TopUpAmountButton.Size = new Size(96, 76);
            TopUpAmountButton.TabIndex = 27;
            TopUpAmountButton.Text = "Credit ";
            TopUpAmountButton.TextAlign = ContentAlignment.BottomCenter;
            TopUpAmountButton.UseVisualStyleBackColor = false;
            TopUpAmountButton.Click += TopUpAmountButton_Click;
            // 
            // HomeButton
            // 
            HomeButton.BackColor = Color.FromArgb(255, 193, 58);
            HomeButton.FlatAppearance.BorderSize = 0;
            HomeButton.FlatAppearance.MouseDownBackColor = Color.Transparent;
            HomeButton.FlatAppearance.MouseOverBackColor = Color.FromArgb(64, 64, 64);
            HomeButton.FlatStyle = FlatStyle.Flat;
            HomeButton.Font = new Font("Arial Narrow", 12F);
            HomeButton.ForeColor = Color.FromArgb(29, 29, 43);
            HomeButton.Image = (Image)resources.GetObject("HomeButton.Image");
            HomeButton.ImageAlign = ContentAlignment.TopCenter;
            HomeButton.Location = new Point(3, 39);
            HomeButton.Margin = new Padding(3, 4, 3, 4);
            HomeButton.Name = "HomeButton";
            HomeButton.Size = new Size(96, 76);
            HomeButton.TabIndex = 22;
            HomeButton.Text = "Home";
            HomeButton.TextAlign = ContentAlignment.BottomCenter;
            HomeButton.UseVisualStyleBackColor = false;
            HomeButton.Click += HomeButton_Click;
            // 
            // ScanCardButton
            // 
            ScanCardButton.BackColor = Color.FromArgb(255, 193, 58);
            ScanCardButton.FlatAppearance.BorderSize = 0;
            ScanCardButton.FlatStyle = FlatStyle.Flat;
            ScanCardButton.Font = new Font("Arial Narrow", 12F);
            ScanCardButton.ForeColor = Color.FromArgb(29, 29, 43);
            ScanCardButton.Image = (Image)resources.GetObject("ScanCardButton.Image");
            ScanCardButton.ImageAlign = ContentAlignment.TopCenter;
            ScanCardButton.Location = new Point(3, 438);
            ScanCardButton.Margin = new Padding(3, 4, 3, 4);
            ScanCardButton.Name = "ScanCardButton";
            ScanCardButton.Size = new Size(96, 76);
            ScanCardButton.TabIndex = 24;
            ScanCardButton.Text = "Scan";
            ScanCardButton.TextAlign = ContentAlignment.BottomCenter;
            ScanCardButton.UseVisualStyleBackColor = false;
            ScanCardButton.Click += ScanCardButton_Click;
            // 
            // ManageBusesButton
            // 
            ManageBusesButton.BackColor = Color.FromArgb(255, 193, 58);
            ManageBusesButton.FlatAppearance.BorderSize = 0;
            ManageBusesButton.FlatStyle = FlatStyle.Flat;
            ManageBusesButton.Font = new Font("Arial Narrow", 12F);
            ManageBusesButton.ForeColor = Color.FromArgb(29, 29, 43);
            ManageBusesButton.Image = (Image)resources.GetObject("ManageBusesButton.Image");
            ManageBusesButton.ImageAlign = ContentAlignment.TopCenter;
            ManageBusesButton.Location = new Point(3, 200);
            ManageBusesButton.Margin = new Padding(3, 4, 3, 4);
            ManageBusesButton.Name = "ManageBusesButton";
            ManageBusesButton.Size = new Size(96, 76);
            ManageBusesButton.TabIndex = 23;
            ManageBusesButton.Text = " Buses";
            ManageBusesButton.TextAlign = ContentAlignment.BottomCenter;
            ManageBusesButton.UseVisualStyleBackColor = false;
            ManageBusesButton.Click += ManageBusesButton_Click;
            // 
            // ManageUserAccountButton
            // 
            ManageUserAccountButton.BackColor = Color.FromArgb(255, 193, 58);
            ManageUserAccountButton.FlatAppearance.BorderSize = 0;
            ManageUserAccountButton.FlatStyle = FlatStyle.Flat;
            ManageUserAccountButton.Font = new Font("Arial Narrow", 12F);
            ManageUserAccountButton.ForeColor = Color.FromArgb(29, 29, 43);
            ManageUserAccountButton.Image = (Image)resources.GetObject("ManageUserAccountButton.Image");
            ManageUserAccountButton.ImageAlign = ContentAlignment.TopCenter;
            ManageUserAccountButton.Location = new Point(3, 116);
            ManageUserAccountButton.Margin = new Padding(3, 4, 3, 4);
            ManageUserAccountButton.Name = "ManageUserAccountButton";
            ManageUserAccountButton.Size = new Size(96, 76);
            ManageUserAccountButton.TabIndex = 26;
            ManageUserAccountButton.Text = "Users";
            ManageUserAccountButton.TextAlign = ContentAlignment.BottomCenter;
            ManageUserAccountButton.UseVisualStyleBackColor = false;
            ManageUserAccountButton.Click += ManageUserAccountButton_Click;
            // 
            // ManageBookingButton
            // 
            ManageBookingButton.BackColor = Color.FromArgb(255, 193, 58);
            ManageBookingButton.FlatAppearance.BorderSize = 0;
            ManageBookingButton.FlatStyle = FlatStyle.Flat;
            ManageBookingButton.Font = new Font("Arial Narrow", 12F);
            ManageBookingButton.ForeColor = Color.FromArgb(29, 29, 43);
            ManageBookingButton.Image = (Image)resources.GetObject("ManageBookingButton.Image");
            ManageBookingButton.ImageAlign = ContentAlignment.TopCenter;
            ManageBookingButton.Location = new Point(3, 278);
            ManageBookingButton.Margin = new Padding(3, 4, 3, 4);
            ManageBookingButton.Name = "ManageBookingButton";
            ManageBookingButton.Size = new Size(96, 76);
            ManageBookingButton.TabIndex = 25;
            ManageBookingButton.Text = "Bookings";
            ManageBookingButton.TextAlign = ContentAlignment.BottomCenter;
            ManageBookingButton.UseVisualStyleBackColor = false;
            ManageBookingButton.Click += ManageBookingButton_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(29, 29, 43);
            panel1.Controls.Add(button3);
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1357, 47);
            panel1.TabIndex = 14;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(29, 29, 43);
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.MouseOverBackColor = Color.Gray;
            button3.FlatStyle = FlatStyle.Flat;
            button3.ForeColor = Color.FromArgb(29, 29, 43);
            button3.Image = (Image)resources.GetObject("button3.Image");
            button3.Location = new Point(1262, 1);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(47, 45);
            button3.TabIndex = 21;
            button3.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(29, 29, 43);
            panel2.Location = new Point(-1, 0);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(24, 881);
            panel2.TabIndex = 15;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(29, 29, 43);
            panel3.Location = new Point(1341, 0);
            panel3.Margin = new Padding(3, 4, 3, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(16, 877);
            panel3.TabIndex = 16;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(29, 29, 43);
            panel4.Location = new Point(-1, 848);
            panel4.Margin = new Padding(3, 4, 3, 4);
            panel4.Name = "panel4";
            panel4.Size = new Size(1367, 33);
            panel4.TabIndex = 17;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(29, 29, 43);
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatAppearance.MouseOverBackColor = Color.Red;
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = Color.FromArgb(29, 29, 43);
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.Location = new Point(1309, 1);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(47, 45);
            button1.TabIndex = 20;
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(255, 193, 58);
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Arial Narrow", 12F);
            button2.ForeColor = Color.FromArgb(29, 29, 43);
            button2.Image = (Image)resources.GetObject("button2.Image");
            button2.ImageAlign = ContentAlignment.TopCenter;
            button2.Location = new Point(3, 522);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(96, 76);
            button2.TabIndex = 28;
            button2.Text = "History";
            button2.TextAlign = ContentAlignment.BottomCenter;
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // MainContainer
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(1355, 876);
            Controls.Add(button1);
            Controls.Add(panel4);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(roundedPanel1);
            Controls.Add(panel3);
            FormBorderStyle = FormBorderStyle.None;
            IsMdiContainer = true;
            Margin = new Padding(3, 4, 3, 4);
            Name = "MainContainer";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            roundedPanel1.ResumeLayout(false);
            panel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private RoundedPanel roundedPanel1;
        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private Button button1;
        private Button button3;
        private Button TopUpAmountButton;
        private Button ScanCardButton;
        private Button ManageUserAccountButton;
        private Button HomeButton;
        private Button ManageBookingButton;
        private Button ManageBusesButton;
        private Button button2;
    }
}
